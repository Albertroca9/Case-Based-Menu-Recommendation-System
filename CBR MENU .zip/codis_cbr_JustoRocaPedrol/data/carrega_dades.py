# data/carrega_dades.py

"""
Càrrega i normalització de les dades del domini gastronòmic.

Aquest mòdul s’encarrega de carregar els CSV i JSON del sistema,
netejar i normalitzar els camps principals (ingredients, sabors,
tècniques, plats, xefs i cultures) i exposar les estructures de dades
necessàries per al funcionament del sistema CBR.
"""

# Imports
import os
import json
import pandas as pd
from utils.helpers import (normalitza_camelcase, normalitza_ingredients_4p, normalitza_sabors_col, normalitza_tecnica_col)


# Paths base
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_INGREDIENTS_PATH = os.path.join(BASE_DIR, "ingredients_processats.json")
JSON_ALERGIES_PATH = os.path.join(BASE_DIR, "alergies_normalitzades.json")

# Carrega CSVs
plats = pd.read_csv(os.path.join(BASE_DIR, "plats.csv"))
cultures = pd.read_csv(os.path.join(BASE_DIR, "cultures.csv"))
chefs = pd.read_csv(os.path.join(BASE_DIR, "chefs.csv"))
ingredients = pd.read_csv(os.path.join(BASE_DIR, "ingredients_def.csv"))
ingredients["Nom-ingredient"] = ingredients["Nom-ingredient"].apply(normalitza_camelcase)
principal_df = pd.read_csv(os.path.join(BASE_DIR, "principal.csv"))

# Normalitzar els noms per evitar problemes
principal_df["Plat"] = principal_df["Plat"].apply(normalitza_camelcase)
principal_df["Ingredient-principal"] = principal_df["Ingredient-principal"].apply(normalitza_camelcase)

# Diccionari: plat → ingredient principal
dicc_principal = {}

for _, fila in principal_df.iterrows():
    nom_plat_norm = normalitza_camelcase(fila["Plat"])
    ing_principal_norm = normalitza_camelcase(fila["Ingredient-principal"])
    dicc_principal[nom_plat_norm] = ing_principal_norm
# Neteja bàsica
def strip_all(df):
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].astype(str).str.strip()
    return df

plats = strip_all(plats)
cultures = strip_all(cultures)
chefs = strip_all(chefs)
ingredients = strip_all(ingredients)

# Normalitzacions
chefs = normalitza_sabors_col(chefs, "Sabors")
ingredients = normalitza_sabors_col(ingredients, "Sabor")
plats = normalitza_sabors_col(plats, "Sabor")

plats = normalitza_tecnica_col(plats, "Tecniques")
chefs = normalitza_tecnica_col(chefs, "Tecniques")
cultures = normalitza_tecnica_col(cultures, "Tecniques-tipiques")

plats["Ingredients-4p"] = plats["Ingredients-4p"].apply(normalitza_ingredients_4p)

# Ingredients vàlids
valid_ingredients = set(
    normalitza_camelcase(x)
    for x in ingredients["Nom-ingredient"].astype(str).tolist()
)

# JSON: Ingredients processats dels plats
with open(JSON_INGREDIENTS_PATH, "r", encoding="utf-8") as f:
    plats_ingredients = json.load(f)

# Construir diccionari: Nom-plat → conjunt d’ingredients
dicc_plat_ingredients = {
    item["Nom-plat"].strip(): {
        normalitza_camelcase(ing["nom"]) for ing in item["ingredients"]
    }
    for item in plats_ingredients
}

# JSON: al·lèrgies normalitzades
with open(JSON_ALERGIES_PATH, "r", encoding="utf-8") as f:
    dicc_alergies_raw = json.load(f)

dicc_alergies = {
    normalitza_camelcase(k): v
    for k, v in dicc_alergies_raw.items()
}

# Variables exportables
df_plats = plats # Alias per compatibilitat cap enrere
__all__ = [
    "plats",
    "cultures",
    "chefs",
    "ingredients",
    "valid_ingredients",
    "plats_ingredients",
    "dicc_plat_ingredients",
    "dicc_alergies",
    "dicc_principal",
    "df_plats"
]