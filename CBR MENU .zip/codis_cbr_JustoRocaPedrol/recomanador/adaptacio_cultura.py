# recomanador/adaptacio_cultura.py

"""
Mòdul d’adaptació cultural dels plats del CBR.

Aquest fitxer implementa l’adaptació d’un plat a una cultura culinària
diferent mitjançant la substitució d’ingredients per alternatives
culturalment coherents, utilitzant similitud semàntica entre ingredients.

Inclou:
- Vectorització semàntica d’ingredients
- Càlcul de similitud cosinus
- Selecció del millor substitut segons cultura
- Actualització del plat, validació del menú i fase RETAIN
"""

# Imports
import numpy as np
import re
from numpy.linalg import norm
from cbr.retain import retain_cas
from cbr.revise import revisar_cas
from utils.helpers import is_no, is_yes, normalitza_camelcase, normalize_text
from data.carrega_dades import ingredients, plats_ingredients, cultures

# Diccionari d’ingredients per plat
dicc_plat_ingredients = {
    item["Nom-plat"]: {ing["nom"] for ing in item["ingredients"]}
    for item in plats_ingredients
}

# Vectors semàntics d’ingredients
def carregar_vectors_ingredients(df_ing):
    """
    Construeix vectors semàntics per als ingredients.

    Genera una representació vectorial de cada ingredient a partir
    de les seves propietats (classe, al·lèrgens, compatibilitats, etc.)
    utilitzant TF-IDF, per facilitar el càlcul de similituds.
    """

    def vector_semantic_simple(row):
        """
        Converteix les propietats d’un ingredient en un text semàntic.

        Combina les característiques rellevants de l’ingredient en una
        cadena de text que servirà com a base per a la vectorització.
        """

        camps = [
            str(row["Classe"]),
            str(row["Subclasse"]),
            str(row["Alergen"]),
            "apte_celiacs_" + str(row["Apte-celíacs"]),
            "apte_vege_" + str(row["Apte-vegetarians"]),
            "apte_vegan_" + str(row["Apte-vegans"]),
            "apte_halal_" + str(row["Apte-halal"]),
            "apte_no_lactosa_" + str(row["Apte-no-lactosa"]),
            "apte_fruits_secs_" + str(row["Apte-fruits-cecs"])
        ]
        return " ".join(camps)

    textos = df_ing.apply(vector_semantic_simple, axis=1).tolist()

    from sklearn.feature_extraction.text import TfidfVectorizer
    vec = TfidfVectorizer()
    matriu = vec.fit_transform(textos).toarray()

    return {nom: matriu[i] for i, nom in enumerate(df_ing["Nom-ingredient"])}

# Similitud cosinus
def similitud_ingredients(a, b, dicc_vectors):
    """
    Calcula la similitud cosinus entre dos ingredients.

    Utilitza els vectors semàntics dels ingredients per mesurar
    el grau de semblança entre ells. Si algun vector no existeix
    o és nul, retorna una similitud zero.
    """

    v1 = dicc_vectors.get(a)
    v2 = dicc_vectors.get(b)

    if v1 is None or v2 is None:
        return 0.0

    n1 = norm(v1)
    n2 = norm(v2)

    if n1 == 0 or n2 == 0:
        return 0.0

    return float(np.dot(v1, v2) / (n1 * n2))

# Millor substitut
def buscar_sustituto_ideal(ingredient, candidats, dicc_vectors, umbral=0.75):
    """
    Cerca el millor ingredient substitut segons similitud semàntica.

    Avalua els candidats disponibles i retorna l’ingredient més similar
    a l’original segons la similitud cosinus, sempre que superi el llindar
    mínim establert.
    """

    millor = None
    millor_sim = 0.0

    for cand in candidats:
        if cand == ingredient:
            continue

        sim = similitud_ingredients(ingredient, cand, dicc_vectors)

        if sim > millor_sim:
            millor_sim = sim
            millor = cand

    if millor and millor_sim >= umbral:
        return millor, millor_sim

    return None, 0.0

# Substituir ingredient en text
def substituir_ingredient_en_text(text, ing_vell, ing_nou):
    """
    Substitueix un ingredient dins del text d’ingredients d’un plat.

    Manté la quantitat i la unitat si existeixen, i reemplaça el nom
    de l’ingredient antic pel nou de manera segura.
    """

    parts = [p.strip() for p in text.split(",") if p.strip()]

    for i, part in enumerate(parts):

        m = re.match(r"([\d\.]+)\s*([A-Za-zÀ-ÿ·]+)\s+(.*)", part)
        if m:
            q, unit, nom = m.groups()
            if normalitza_camelcase(nom) == ing_vell:
                parts[i] = f"{q} {unit} {ing_nou}"
                continue

        if normalitza_camelcase(part) == ing_vell:
            parts[i] = ing_nou

    return ", ".join(parts)


# Adaptació per cultura
def adaptar_origen_plat_CASE(menu_actual, plats, cultures, dicc_plat_ingredients, preferencies=None, umbral=0.75):
    """
    Adapta un plat del menú a una cultura culinària diferent.

    Substitueix ingredients del plat per alternatives pròpies de la
    cultura seleccionada utilitzant similitud semàntica, manté un
    historial d’adaptacions, valida el menú resultant i el guarda
    al sistema CBR.
    """

    if preferencies is None:
        preferencies = {}

    # Inicialitzar historial d’adaptacions
    if not hasattr(menu_actual, "adaptacions"):
        menu_actual.adaptacions = []

    dicc_vectors = carregar_vectors_ingredients(ingredients)

    while True:

        print("\n==================== ADAPTACIÓ PER ORIGEN ====================")

        # Secció plat
        opcions_plats = []

        if menu_actual.plats["entrants"]:
            opcions_plats.extend(menu_actual.plats["entrants"])

        for k in ["principal", "segon", "postre"]:
            if menu_actual.plats[k]:
                opcions_plats.append(menu_actual.plats[k])

        print("Quin plat vols adaptar?\n")
        for i, p in enumerate(opcions_plats, 1):
            print(f" {i}. {p['Nom-plat']}")

        try:
            idx = int(input(" >> ")) - 1
            plat_data = opcions_plats[idx]
            plat_sel = plat_data["Nom-plat"]
        except:
            print("Selecció no vàlida.")
            continue

        # Selecció cultura
        plat_norm = normalitza_camelcase(plat_sel)

        if "NomNorm" not in plats.columns:
            plats["NomNorm"] = plats["Nom-plat"].apply(normalitza_camelcase)

        fila = plats[plats["NomNorm"] == plat_norm]
        origen_actual = fila.iloc[0]["Origen-plat"] if not fila.empty else "Desconegut"

        print(f"\nA quina cultura vols adaptar el plat? (origen actual: {origen_actual})\n")

        cultures_disp = cultures["Cultura"].unique().tolist()
        for i, c in enumerate(cultures_disp, 1):
            print(f" {i}. {c}")

        try:
            cultura_sel = cultures_disp[int(input(" >> ")) - 1]
        except:
            print("Selecció no vàlida.")
            continue

        fila_cult = cultures[cultures["Cultura"] == cultura_sel].iloc[0]

        # Substitució d’ingredients
        raw = str(fila_cult["Ingredients-tipics"])
        ings_cultura = [
            normalitza_camelcase(x.strip())
            for x in re.split(r"[,;]+", raw)
            if x.strip()
        ]

        valid_ing = set(normalitza_camelcase(x) for x in ingredients["Nom-ingredient"])
        ings_cultura = [x for x in ings_cultura if x in valid_ing]

        ings_plat = {
            normalitza_camelcase(x)
            for x in dicc_plat_ingredients.get(plat_sel, set())
        }

        canvis = []
        text_nou = plat_data["Ingredients-4p"]

        for ing in list(ings_plat):
            subst, score = buscar_sustituto_ideal(
                ing, ings_cultura, dicc_vectors, umbral
            )

            if subst and subst not in preferencies.get("ingredients_prohibits", []):
                canvis.append((ing, subst, score))
                text_nou = substituir_ingredient_en_text(text_nou, ing, subst)

        # Resultat
        print("\n=========== RESULTAT DE L'ADAPTACIÓ ===========")
        print(f"Plat: {plat_sel}")
        print(f"Cultura aplicada: {cultura_sel}")

        if not canvis:
            print("Cap ingredient s’ha pogut substituir.")
        else:
            print("Ingredients substituïts:")
            for a, b, s in canvis:
                print(f" - {a} → {b} (sim={s:.2f})")

            # Registrar adaptacions
            for ing_vell, ing_nou, score in canvis:
                menu_actual.adaptacions.append({
                    "tipus": "cultura",
                    "plat": plat_sel,
                    "ingredient_abans": ing_vell,
                    "ingredient_despres": ing_nou,
                    "cultura_aplicada": cultura_sel,
                    "similitud": round(score, 3),
                    "motiu": f"Adaptació del plat a la cultura {cultura_sel}"
                })

            plat_data["Ingredients-4p"] = text_nou
            plat_data["Origen-plat"] = cultura_sel
            plat_data["Nom-plat"] += f" (origen {cultura_sel})"

        input("\nPrem ENTER per continuar...")

        r = input("Vols adaptar un altre plat d’aquest mateix menú? (Si/No)\n >> ").strip()
        if is_yes(normalize_text(r)):
            continue

        # Validació + Retain
        print("\nValidant el menú adaptat...")
        ok = revisar_cas(menu_actual, preferencies, [])[1]
        print("✓ El menú adaptat és coherent!" if ok else "⚠ El menú adaptat NO és coherent.")

        retain_cas(menu_actual)
        print("✓ Cas guardat amb historial d’adaptacions.")

        r2 = input("Vols adaptar un altre menú recomanat? (Si/No)\n >> ").strip()
        if is_yes(normalize_text(r2)):
            return "__SELECT_ANOTHER_MENU__"

        return "__FINISHED_SUCCESS__"
