# recomanador/adaptacio_allergies.py

"""
Adaptació de menús segons al·lèrgies alimentàries.

Aquest mòdul permet detectar ingredients amb al·lèrgies dins dels plats
d’un menú i substituir-los per variants segures, actualitzant el menú,
validant-ne la coherència i guardant el cas adaptat amb feedback.
"""

# Imports
import re
from data.carrega_dades import dicc_alergies, dicc_plat_ingredients
from utils.helpers import (normalitza_camelcase, camel_to_text, format_variant_with_quantity)
from cbr.revise import revisar_cas
from cbr.retain import retain_cas

# Assignar ID únic i nom original al plat
def assegurar_ids_plat(plat):
    """
    Garanteix que cada plat tingui un identificador intern únic.
    """
    if "_id" not in plat:
        plat["_id"] = id(plat)
    if "_original_name" not in plat:
        plat["_original_name"] = plat["Nom-plat"]


# Actualitzar el plat dins del menú segons el seu _id
def actualitzar_plat_al_menu(cas, plat_sel):
    """
    Substitueix un plat dins del menú usant _id (més segur que el nom).
    """
    for tipus in ["entrants", "principal", "segon", "postre"]:
        plats_t = cas.plats.get(tipus)

        if tipus == "entrants":
            for i, p in enumerate(plats_t):
                if p.get("_id") == plat_sel["_id"]:
                    cas.plats["entrants"][i] = plat_sel
                    return

        else:
            p = cas.plats.get(tipus)
            if p and p.get("_id") == plat_sel["_id"]:
                cas.plats[tipus] = plat_sel
                return


# Actualitzar diccionari ingredients
def actualitzar_diccionari_ingredients(plat_sel, norm_ant, norm_nou):
    """
    Actualitza el diccionari d’ingredients d’un plat.

    Substitueix un ingredient normalitzat per un altre dins de
    `dicc_plat_ingredients` per mantenir la coherència amb
    les adaptacions aplicades al menú.
    """

    nom_orig = plat_sel["_original_name"]
    if nom_orig in dicc_plat_ingredients:
        if norm_ant in dicc_plat_ingredients[nom_orig]:
            dicc_plat_ingredients[nom_orig].remove(norm_ant)
        dicc_plat_ingredients[nom_orig].add(norm_nou)


# Funció principal d'adaptació 
def adaptar_per_allergies_MULTIPLE(cas_adults, cas_infantil, preferencies):
    """
    Adapta un menú per gestionar múltiples al·lèrgies alimentàries.

    Permet revisar els plats del menú, detectar ingredients amb
    al·lèrgies, substituir-los per alternatives segures segons les
    preferències de l’usuari, validar el resultat i guardar el cas
    adaptat amb feedback.
    """

    cas = cas_adults if cas_adults is not None else cas_infantil

    while True:

        print("\n==================== ADAPTACIÓ PER AL·LÈRGIA ====================\n")

        # Llista plats
        plats_llista = []

        if cas.plats["entrants"]:
            for e in cas.plats["entrants"]:
                assegurar_ids_plat(e)
                plats_llista.append(("Entrant", e))

        for key, label in [
            ("principal", "Principal"),
            ("segon",     "Segon"),
            ("postre",    "Postre")
        ]:
            p = cas.plats[key]
            if p:
                assegurar_ids_plat(p)
                plats_llista.append((label, p))

        print("\nPlats disponibles:\n")
        for i, (tipus, p) in enumerate(plats_llista, 1):
            print(f"  {i}. {tipus}: {p['Nom-plat']}")

        # Triar plat
        while True:
            op = input("\nQuin plat vols revisar? (número)\n  >> ").strip()
            if op.isdigit() and 1 <= int(op) <= len(plats_llista):
                tipus_sel, plat_sel = plats_llista[int(op)-1]
                break
            print("Número incorrecte.")

        assegurar_ids_plat(plat_sel)

        print(f"\nRevisant al·lèrgies de: {plat_sel['Nom-plat']}\n")

        # Obtenir ingredients del plat
        ing_text = plat_sel["Ingredients-4p"]
        parts = [p.strip() for p in ing_text.split(",") if p.strip()]

        conflictes = []

        print("Ingredients i possibles al·lèrgies:\n")

        for p in parts:
            trobat = re.match(r"([\d\.]+)\s*([a-zA-Zà-úÀ-Ú·]*)\s*(.*)", p)
            if not trobat:
                print(f"  - {p}   (no identificat)")
                continue

            nom_ing = trobat.group(3).strip()
            nom_norm = normalitza_camelcase(nom_ing)

            info = dicc_alergies.get(nom_norm)

            if info:
                print(f"  - {p}   →   ⚠ {', '.join(info['alergies'])}")
                conflictes.append((p, nom_norm, info))
            else:
                print(f"  - {p}   ✔ Sense al·lèrgies conegudes")

        # Sense conflictes
        if not conflictes:
            print("\n✔ Aquest plat NO té ingredients amb al·lèrgies.\n")

            r = input("Vols revisar un altre plat d’aquest mateix menú? (Si/No)\n >> ").lower()
            if r.startswith("s"):
                continue

            r2 = input("Vols adaptar un altre menú recomanat? (Si/No)\n >> ").lower()
            if r2.startswith("s"):

                g = input("\nVols guardar aquest menú adaptat? (Si/No)\n >> ").lower()
                if g.startswith("s"):
                    retain_cas(cas)
                    print("✓ Cas guardat correctament.")
                return "__SELECT_ANOTHER_MENU__"

            g = input("\nVols guardar aquest menú adaptat? (Si/No)\n >> ").lower()
            if g.startswith("s"):
                retain_cas(cas)
                print("✓ Cas guardat correctament.")

            r3 = input("\nVols iniciar un nou recomanador? (Si/No)\n >> ").lower()
            if r3.startswith("s"):
                return "__RESTART_ALL__"

            return "__FINISHED_NOT_SAVED__"


        # Triar ingredient conflictiu
        print("\nIngredients amb al·lèrgies:\n")
        for i, (orig, nn, info) in enumerate(conflictes, 1):
            print(f"  {i}. {orig} → {', '.join(info['alergies'])}")

        while True:
            op_i = input("\nQuin ingredient vols substituir? (número)\n  >> ").strip()
            if op_i.isdigit() and 1 <= int(op_i) <= len(conflictes):
                idx = int(op_i) - 1
                break
            print("Número incorrecte.")

        orig, norm_ant, info = conflictes[idx]

        # Triar variant segura
        print(f"\nSubstituint ingredient: {orig}\nVariants disponibles:\n")

        variants = info["variants"]

        # Filtrar variants prohibides
        if preferencies and "ingredients_prohibits" in preferencies:
            variants_filtrades = [
                v for v in variants
                if v not in preferencies["ingredients_prohibits"]
            ]
        else:
            variants_filtrades = variants

        # Si totes les variants estan prohibides → cas especial
        if not variants_filtrades:
            print(" Cap alternativa disponible perquè totes estan prohibides per preferències.")
            print(" Aquest ingredient s'haurà d'eliminar manualment o substituir per un altre plat.")
            return "__NO_VARIANTS_AVAILABLE__"

        print("\nVariants disponibles:\n")
        for i, v in enumerate(variants_filtrades, 1):
            print(f"  {i}. {camel_to_text(v).capitalize()}")

        while True:
            op_v = input("\nQuina alternativa vols utilitzar? (número)\n  >> ").strip()
            if op_v.isdigit() and 1 <= int(op_v) <= len(variants_filtrades):
                nova = variants_filtrades[int(op_v)-1]
                break
            print("Número incorrecte.")

        # Aplicar canvi a Ingredients-4p
        for i in range(len(parts)):
            if parts[i] == orig:
                parts[i] = format_variant_with_quantity(orig, nova)
                break

        plat_sel["Ingredients-4p"] = ", ".join(parts)

        # Actualitzar nom del plat
        alergia_txt = ", ".join(info["alergies"])
        if "(sense" not in plat_sel["Nom-plat"]:
            plat_sel["Nom-plat"] += f" (sense {alergia_txt})"
        else:
            # evitar repetir noms
            base = plat_sel["_original_name"]
            plat_sel["Nom-plat"] = base + f" (sense {alergia_txt})"

        # Actualitzar dicc_plat_ingredients
        actualitzar_diccionari_ingredients(plat_sel, norm_ant, nova)

        # Escriure el canvi al menú real
        actualitzar_plat_al_menu(cas, plat_sel)

        print("\n✓ Ingredient substituït correctament!\n")

        # Validació
        print("Validant el menú adaptat...")
        ok = revisar_cas(cas, preferencies, [])[1]

        if ok:
            print("✓ El menú adaptat és coherent!\n")
        else:
            print("⚠ El menú adaptat NO és coherent!\n")

        # Guardar sempre el cas + feedback
        from utils.feedback import demanar_feedback

        feedback = demanar_feedback()
        cas.feedback = feedback

        retain_cas(cas)
        print("✓ Cas guardat amb feedback.")

        # Flux segons feedback
        if feedback["status"] == "SUCCESS":
            print("\nEl menú ha estat ben valorat.")
            return "__FINISHED_SUCCESS__"
        else:
            print("\nEl menú s'ha marcat com a FRACÀS.")

            # Tornem sempre al menú d’adaptacions
            return "__BACK_TO_ADAPTATIONS__"
