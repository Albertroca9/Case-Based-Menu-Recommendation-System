# recomanador/recom.py

"""
Mòdul principal de recomanació del sistema RicoRico.

Conté la lògica central per:
- Recollir les preferències de l’usuari
- Recuperar menús similars mitjançant Case-Based Reasoning (CBR)
- Gestionar la fase d’adaptació interactiva dels menús recomanats
- Coordinar les diferents estratègies d’adaptació disponibles
- Mostrar la recomanació final i els seus detalls associats

Aquest mòdul actua com a punt d’entrada del flux de recomanació,
connectant la interacció amb l’usuari amb la base de coneixement
i els mecanismes d’adaptació del sistema.
"""

# Imports
import re
import time
from copy import deepcopy
from utils.helpers import (ask, check_exit, check_reset, normalize_text, is_yes, is_no, ask_exit_confirmation, ask_restart_confirmation, neteja_ingredient_usuari, normalitza_camelcase, RED, RESET, user_wants_reset, user_wants_exit)
from cbr.retrieve import retrieve_best
from cbr.reuse import adaptar_cas, substituir_plat_CASE
from cbr.revise import revisar_cas
from cbr.retain import retain_cas
from data.carrega_dades import (plats as df_plats, cultures, chefs, ingredients, plats_ingredients, valid_ingredients, dicc_alergies)
from recomanador.adaptacio_ingredients import adaptar_consultar_modificar_ingredients_CASE
from recomanador.adaptacio_allergies import adaptar_per_allergies_MULTIPLE
from recomanador.adaptacio_chef import adaptar_estil_plat_MULTIPLE
from recomanador.adaptacio_cultura import adaptar_origen_plat_CASE

dicc_plat_ingredients = {
    item["Nom-plat"]: {ing["nom"] for ing in item["ingredients"]}
    for item in plats_ingredients
}

# Formulari de preferències de l’usuari
def obtenir_valor_camp(camp, data):
    """
    Repregunta un camp concret i retorna el nou valor.
    """

    if camp == "esdeveniment":
        return ask("Tipus d’esdeveniment:",
                   options=["Boda","Comunió","Bateig","Congrés"])

    if camp == "comensals_totals":
        while True:
            v = ask("Número total de comensals:", int)
            if v == "__RESTART_ALL__":
                return "__RESTART_ALL__"
            if v > 0:
                # Si comensals baixa, ajustar nens
                data["nens"] = min(data["nens"], v)
                return v
            print("Ha de ser positiu.")

    if camp == "nens":
        while True:
            v = ask("Quants nens hi haurà?", int)
            if v == "__RESTART_ALL__":
                return "__RESTART_ALL__"
            if 0 <= v <= data["comensals_totals"]:
                return v
            print("Valor invàlid.")

    if camp == "temporada":
        return ask("Temporada:",
                   options=["Primavera","Estiu","Tardor","Hivern","Anual"])

    if camp == "estil_menu":
        return ask("Estil:",
                   options=["Classic","Modern","Sibarita"])

    if camp == "complexitat_adults":
        return ask("Complexitat adults:",
                   options=["Baixa","Mitjana","Alta"])

    if camp == "menu_infantil":
        return ask("Vols menú infantil?",
                   options=["Si","No"])

    if camp == "complexitat_infantil":
        return ask("Complexitat infantil:",
                   options=["Baixa","Mitjana"])

    if camp == "beguda":
        return ask("Beguda principal:",
                   options=["Vi","Maridatge"])

    if camp == "ingredients_prohibits":
        print("Ingredients a evitar ('-' si cap):")
        txt = input("  >> ").strip()

        if normalize_text(txt) == "-":
            return []

        # Normalitzar
        parts = re.split(r"[,;]+", txt)
        result = []

        for p in parts:
            p = p.strip()
            if not p:
                continue

            p_norm = normalitza_camelcase(p)

            if p_norm in valid_ingredients:
                result.append(p_norm)
            else:
                print(f"L’ingredient «{p}» no existeix a la base. S’ignorarà.")

        return result

    # fallback
    return data[camp]

def obtenir_preferencies():
    """
    Recull les preferències de l’usuari de manera interactiva.

    Demana i valida totes les dades necessàries per a la recomanació
    de menús (esdeveniment, comensals, estil, temporada, begudes i
    ingredients prohibits) i retorna un diccionari amb les
    preferències confirmades.
    """

    while True:
        data = {}

        # Esdeveniment
        val = ask("Tipus d’esdeveniment (Boda/Comunió/Bateig/Congrés):",
                  options=["Boda","Comunió","Bateig","Congrés"])
        if val == "__RESTART_ALL__":
            continue
        data["esdeveniment"] = val

        # Comensals totals
        while True:
            val = ask("Número total de comensals:", int)
            if val == "__RESTART_ALL__":
                break
            if val > 0:
                data["comensals_totals"] = val
                break
            print("Ha de ser positiu.")
        if val == "__RESTART_ALL__":
            continue

        # Nens
        while True:
            val = ask("Quants nens hi haurà?", int)
            if val == "__RESTART_ALL__":
                break

            # nens < comensals totals → ha d'haver com a mínim 1 adult
            if val < data["comensals_totals"] and val >= 0:
                data["nens"] = val
                break

            # Missatge personalitzat
            if val == data["comensals_totals"]:
                print("Ha d’haver-hi com a mínim un adult. Torna-ho a intentar.")
            elif val > data["comensals_totals"]:
                print("El nombre de nens no pot superar el total de comensals.")
            else:
                print("Valor invàlid.")

        adults = data["comensals_totals"] - data["nens"]
        print(f"Total comensals: {adults} adults i {data['nens']} nens")

        # Temporada
        val = ask("Temporada (Primavera/Estiu/Tardor/Hivern/Anual):",
                  options=["Primavera","Estiu","Tardor","Hivern","Anual"])
        if val == "__RESTART_ALL__":
            continue
        data["temporada"] = val

        # Estil
        val = ask("Estil (Classic/Modern/Sibarita):",
                  options=["Classic","Modern","Sibarita"])
        if val == "__RESTART_ALL__":
            continue
        data["estil_menu"] = val

        # Complexitat adults
        val = ask("Complexitat adults (Baixa/Mitjana/Alta):",
                  options=["Baixa","Mitjana","Alta"])
        if val == "__RESTART_ALL__":
            continue
        data["complexitat_adults"] = val

        # Menú infantil 
        if data["nens"] > 0:
            val = ask("Vols menú infantil? (Si/No):", options=["Si","No"])
            if val == "__RESTART_ALL__":
                continue
            data["menu_infantil"] = val
        else:
            data["menu_infantil"] = "No"

        # Complexitat infantil
        if normalize_text(data["menu_infantil"]) == "si":
            val = ask("Complexitat infantil (Baixa/Mitjana):",
                      options=["Baixa","Mitjana"])
            if val == "__RESTART_ALL__":
                continue
            data["complexitat_infantil"] = val
        else:
            data["complexitat_infantil"] = None

        # Beguda
        val = ask("Beguda principal (Vi/Maridatge):",
                  options=["Vi","Maridatge"])
        if val == "__RESTART_ALL__":
            continue
        data["beguda"] = val

        # Ingredients prohibits
        print("Ingredients a evitar ('-' si cap):")
        time.sleep(0.1)
        ing = input("  >> ").strip()

        # exit / reset universal
        if check_exit(ing):
            continue
        if check_reset(ing):
            continue

        if normalize_text(ing) == "-":
            data["ingredients_prohibits"] = []
        else:
            raw_parts = re.split(r"[,;]+", ing)
            ingredients_bons = []

            for p in raw_parts:
                p = p.strip()
                if not p:
                    continue

                # Netejar i normalitzar
                p_net = neteja_ingredient_usuari(p)
                p_norm = normalitza_camelcase(p_net)

                # Ingredient exacte
                if p_norm in valid_ingredients:
                    print(f"  ✓ Acceptat com a ingredient prohibit: {p_norm}")
                    ingredients_bons.append(p_norm)
                    continue

                # Buscar coincidències parcials
                similars = [x for x in valid_ingredients if p_norm.lower() in x.lower()]

                if similars:
                    print(f"\n  L’ingredient «{p}» no existeix exactament.")
                    print("  Potser volies dir:")
                    for i, s in enumerate(similars, 1):
                        print(f"    {i}. {s}")

                    sel = input("  Escriu el número per seleccionar-lo o ENTER per ignorar:\n  >> ").strip()
                    if sel.isdigit() and 1 <= int(sel) <= len(similars):
                        chosen = similars[int(sel)-1]
                        print(f"  ✓ Ingredient prohibit acceptat: {chosen}\n")
                        ingredients_bons.append(chosen)
                    else:
                        print("  · Cap ingredient serà exclòs per aquesta entrada.\n")
                else:
                    print(f"  ✗ L’ingredient «{p}» no existeix a la base.")
                    print("    → No s’exclourà cap plat per aquest ingredient.\n")

            data["ingredients_prohibits"] = ingredients_bons


        if normalize_text(ing) == "-":
            data["ingredients_prohibits"] = []
        else:
            ingredients_bons = []
            for p in re.split(r"[;,]+", ing):
                p = p.strip()
                if not p:
                    continue
                p_n = neteja_ingredient_usuari(p)
                p_norm = normalitza_camelcase(p_n)

                if p_norm in valid_ingredients:
                    ingredients_bons.append(p_norm)
                else:
                    # Suggeriments
                    similars = [x for x in valid_ingredients if p_norm.lower() in x.lower()]
                    if similars:
                        print(f"L’ingredient «{p}» no existeix exactament. Potser volies dir:")
                        for i, s in enumerate(similars, 1):
                            print(f"  {i}. {s}")
                        sel = input("Escull número o ENTER per ignorar:\n  >> ").strip()
                        if sel.isdigit() and 1 <= int(sel) <= len(similars):
                            ingredients_bons.append(similars[int(sel)-1])

            data["ingredients_prohibits"] = ingredients_bons

        # RESUM FINAL
        while True:

            # Mostrar resum
            print("\n================== RESUM DE PREFERENCIES ==================")
            for k, v in data.items():
                print(f"{k}: {v}")
            print("===========================================================\n")

            resp = input("Són correctes aquestes preferències? (Si/No)\n  >> ").strip().lower()

            # Permetre exit/reset
            if check_exit(resp):
                continue
            if check_reset(resp):
                break # restart total

            # Quan són correctes → confirmar i sortir
            if resp.startswith("s"):
                print("Preferències confirmades.")
                return data

            # Quan són incorrectes → preguntar què modificar
            elif resp.startswith("n"):

                print("\nQuin camp vols modificar?")
                print("Opcions: esdeveniment, comensals_totals, nens, temporada,")
                print("         estil_menu, complexitat_adults, menu_infantil,")
                print("         complexitat_infantil, beguda, ingredients_prohibits")

                camp = input("  >> ").strip()

                # exit/reset
                if check_exit(camp):
                    continue
                if check_reset(camp):
                    break

                camp_norm = normalize_text(camp)

                if camp_norm not in data:
                    print("Categoria no reconeguda.")
                    continue

                # Modificar només aquell camp
                nou_valor = obtenir_valor_camp(camp_norm, data)

                if nou_valor == "__RESTART_ALL__":
                    break

                data[camp_norm] = nou_valor

                # Ajust conexos
                if camp_norm == "nens" and data["nens"] == 0:
                    data["menu_infantil"] = "No"
                    data["complexitat_infantil"] = None

                # Ens torna al resum
                continue

            else:
                print("Respon Si o No.")


# Pipeline CBR complet
def recomanar_menu(preferències):
    """
    Executa el pipeline CBR complet de recomanació de menús.

    Recupera els menús més similars segons les preferències,
    aplica adaptacions, valida els resultats i retorna el
    millor menú juntament amb el TOP 3.
    """

    import time
    start = time.time()

    # Retrieve
    top3_adults, sims_adults = retrieve_best(preferències, infantil=False)

    if preferències["menu_infantil"].lower() == "si":
        top3_infantil, sims_infantil = retrieve_best(preferències, infantil=True)
    else:
        top3_infantil = []
        sims_infantil = []

    # Top 3
    RED = "\033[91m"
    RESET = "\033[0m"

    # Adults
    print(f"\n{RED}========== TOP 3 MENÚS ADULTS MÉS SIMILARS =========={RESET}")
    for i, (cas, s) in enumerate(top3_adults, start=1):
        print(f"{RED}{i}. {cas.menu_id:<12} → similitud = {s:.3f}{RESET}")
    print(f"{RED}" + "-"*52 + RESET)

    # Infantil
    if top3_infantil:
        print(f"\n{RED}====== TOP 3 MENÚS INFANTILS MÉS SIMILARS ======{RESET}")
        for i, (cas, s) in enumerate(top3_infantil, start=1):
            print(f"{RED}{i}. {cas.menu_id:<12} → similitud = {s:.3f}{RESET}")
        print(f"{RED}" + "-"*52 + RESET)

    # Processar adults
    recomanacions_adults = []

    for cas_original, sim in top3_adults:
        cas_adaptat, canvis = adaptar_cas(cas_original, sims_adults, preferències)
        cas_final, _ = revisar_cas(cas_adaptat, preferències, canvis)
        recomanacions_adults.append((cas_final, sim))

    # Processar infantil
    recomanacions_infantil = []

    if top3_infantil:
        for cas_original, sim in top3_infantil:
            cas_adaptat, canvis = adaptar_cas(cas_original, sims_infantil, preferències)
            cas_final, _ = revisar_cas(cas_adaptat, preferències, canvis)
            recomanacions_infantil.append((cas_final, sim))

    # Retorn final
    end = time.time()
    temps_execucio = end - start

    # Crear carpeta data si no existe
    import os
    if not os.path.exists("data"):
        os.makedirs("data")

    # Guardar tiempo
    with open("data/time_log.txt", "a") as f:
        f.write(f"{temps_execucio}\n")

    # Ejecutar fase FORGET
    from cbr.forget import forget_cases_based_on_time
    forget_cases_based_on_time()

    return {
        "cas_adults": recomanacions_adults[0][0], # el millor menú  (per main.py)
        "sim_adults": recomanacions_adults[0][1],

        "cas_infantil": (recomanacions_infantil[0][0] if recomanacions_infantil else None),
        "sim_infantil": (recomanacions_infantil[0][1] if recomanacions_infantil else None),

        "top3_adults": list(recomanacions_adults),
        "top3_infantil": list(recomanacions_infantil)
    }

def imprimir_begudes_generals():
    """
    Mostra les begudes generals incloses per defecte al menú.

    Aquestes begudes s’ofereixen a tots els comensals
    independentment del menú seleccionat.
    """

    print("\n" + "=" * 60)
    print("                 BEGUDES GENERALS")
    print("=" * 60)
    print("Aquestes begudes s’ofereixen a tots els comensals,")
    print("independentment del menú seleccionat:\n")

    print("  • Aigua mineral (amb i sense gas)")
    print("  • Refrescos (cola, llimona, taronja)")
    print("  • Cervesa (amb i sense alcohol)")
    print("  • Sucs de fruita variats\n")

    print(f"Cost fix per persona: 3.50 €")
    print("=" * 60 + "\n")

def imprimir_maridatge(adults):
    """
    Imprimeix una proposta de maridatge complet.

    Calcula el consum estimat i el cost total del maridatge
    segons el nombre d’adults.
    """

    print("\n" + "=" * 60)
    print("                 MARIDATGE PERSONALITZAT")
    print("=" * 60)
    print("Has seleccionat l’opció de maridatge complet. Et proposem un")
    print("conjunt de vins i begudes perfectament ajustats a cada tipus")
    print("de plat.\n")

    def line(txt, price):
        """
        Imprimeix una línia formatada d’una beguda del maridatge.

        Mostra el nom de la beguda i el seu preu alineats
        per facilitar la lectura del llistat.
        """
        print(f"  • {txt:<50} {price:>6.2f}€")

    begudes_maridatge = [
        ("Còctel suau de fruites o vermut blanc", 8.00),
        ("Cava brut rosat (entrada fresca)", 12.00),
        ("Vi negre reserva (DO Priorat)", 23.00),
        ("Vi negre criança (DO Rioja)", 26.00),
        ("Vi blanc afruitat (DO Penedès)", 18.00),
        ("Vi blanc sec (DO Rías Baixas)", 22.00),
        ("Vi negre jove (DO Terra Alta)", 14.00),
        ("Vi dolç moscatell o mistela", 12.00),
        ("Cava semisec (acabament elegant)", 15.00)
    ]

    print("ENTRANTS:")
    line(*begudes_maridatge[0])
    line(*begudes_maridatge[1])
    print()

    print("PLATS DE CARN:")
    line(*begudes_maridatge[2])
    line(*begudes_maridatge[3])
    print()

    print("PLATS DE PEIX:")
    line(*begudes_maridatge[4])
    line(*begudes_maridatge[5])
    print()

    print("PLATS D’ESTOFAT O GUISAT:")
    line(*begudes_maridatge[6])
    print()

    print("POSTRES:")
    line(*begudes_maridatge[7])
    line(*begudes_maridatge[8])
    print()

    print("-" * 60)

    # Resum numèric detallat
    preus = [p for (_, p) in begudes_maridatge]

    consum_per_ampolla = 4 # 1 ampolla per cada 4 adults
    ampolles_per_tipus = adults / consum_per_ampolla
    ampolles_totals = ampolles_per_tipus * len(preus)
    cost_total = sum(preus) * ampolles_per_tipus

    print("Recomanació segons la complexitat del maridatge:")
    print(f"  - Begudes del maridatge: {len(preus)} tipus")
    print(f"  - Preu base (1 ampolla per tipus): {sum(preus):.2f}€")
    print(f"  - Adults: {adults}")
    print(f"  - Consum estimat: 1 ampolla per cada {consum_per_ampolla} adults")
    print(f"  - Ampolles necessàries per tipus: {ampolles_per_tipus:.2f}")
    print(f"  - Ampolles totals (totes les begudes): {ampolles_totals:.2f}")
    print(f"  - Cost total estimat: {cost_total:.2f}€")
    print(f"  - Cost per persona: {cost_total / adults:.2f}€")

    print("-" * 60 + "\n")

def imprimir_vins(complexitat, adults):
    """
    Mostra una recomanació de vins segons la complexitat del menú.

    Calcula el cost total i el cost per persona en funció
    del nombre d’adults.
    """

    print("\n" + "=" * 60)
    print("                 RECOMANACIÓ DE VINS")
    print("=" * 60)
    print(f"Complexitat seleccionada: {complexitat}\n")

    # Selecció de vins segons complexitat
    if complexitat.lower() == "baixa":
        vins = [
            ("Vi blanc jove (DO Catalunya)", 10.00),
            ("Vi negre jove (DO Terra Alta)", 12.00),
            ("Vi dolç o moscatell per als postres", 8.50)
        ]
        cost_base = 30.50

    elif complexitat.lower() == "mitjana":
        vins = [
            ("Vi blanc afruitat (DO Penedès)", 15.00),
            ("Vi negre criança (DO Rioja)", 18.00),
            ("Cava brut nature per als postres", 14.00)
        ]
        cost_base = 47.00

    else: # alta
        vins = [
            ("Vi blanc reserva (DO Rueda)", 20.00),
            ("Vi negre reserva (DO Priorat)", 24.00),
            ("Vi ranci o cava gran reserva per al final", 22.00)
        ]
        cost_base = 66.00

    # Imprimir vins alineats
    for nom, preu in vins:
        print(f"  • {nom:<50} {preu:>6.2f}€")

    # Càlcul real per nombre d’adults
    # Regla professional: 1 ampolla per cada 4 adults
    amp_per_tipus = adults / 4

    # Cost total = suma(preu_vi * amp_per_tipus)
    cost_total = sum(preu * amp_per_tipus for _, preu in vins)

    # Cost per persona
    cost_per_persona = cost_total / adults

    print("\n" + "-" * 60)
    print("Recomanació segons la complexitat:")
    print(f"  - Preu base (3 ampolles): {cost_base:.2f}€")
    print(f"  - Adults: {adults}")
    print(f"  - Consum estimat: 1 ampolla per cada 4 adults")
    print(f"  - Ampolles necessàries per tipus: {amp_per_tipus:.2f}")
    print(f"  - Ampolles totals (3 vins): {amp_per_tipus * 3:.2f}")
    print(f"  - Cost total estimat: {cost_total:.2f}€")
    print(f"  - Cost per persona: {cost_per_persona:.2f}€")
    print("-" * 60 + "\n")

def imprimir_pastis_boda(complexitat, adults):
    """
    Imprimeix les opcions de pastís de boda disponibles.

    Recomana un pastís segons la complexitat del menú
    i calcula el cost per persona.
    """

    print("\n" + "=" * 60)
    print("                 OPCIONS DE PASTÍS DE BODA")
    print("=" * 60)
    print("Et presentem les opcions disponibles per al pastís de boda,")
    print("totes elles preparades artesanalment i adaptades al teu")
    print("esdeveniment.\n")

    opcions = [
        ("Pastís de tres pisos amb fondant", 485.63),
        ("Pastís amb nata vegetal i fruites vermelles", 241.50),
        ("Mini pastís amb cobertura de xocolata negra", 126.00)
    ]

    # Columna de text per evitar que el preu surti dels 60 caràcters
    COL_TEXT = 48

    # Llista d’opcions alineades com al maridatge
    for idx, (nom, preu) in enumerate(opcions, 1):
        print(f"  {idx}. {nom:<{COL_TEXT}}{preu:>8.2f}€")

    print("-" * 60)

    # Recomanació segons la complexitat
    if complexitat.lower() == "alta":
        nom, preu = opcions[0]
    elif complexitat.lower() == "mitjana":
        nom, preu = opcions[1]
    else:
        nom, preu = opcions[2]

    print(f"\nRecomanació segons la complexitat ({complexitat}):")
    print(f"  → {nom} – {preu:.2f}€ (total)")
    print(f"    Cost per persona: {(preu / adults):.2f}€")

    print("=" * 60 + "\n")

# Impressió completa
def imprimir_recomanacio(recom, preferencies, df_plats):
    """
    Imprimeix la recomanació completa del menú.

    Mostra el menú seleccionat, els plats, preus,
    begudes, maridatge o vins i altres costos associats.
    """

    cas_adults = recom.get("cas_adults")
    sim_adults = recom.get("sim_adults")

    cas_infantil = recom.get("cas_infantil")
    sim_infantil = recom.get("sim_infantil")

    adults = preferencies["comensals_totals"] - preferencies["nens"]
    nens = preferencies["nens"]

    # Funcions auxiliars
    def print_plat_case(plat_case):
        """
        Imprimeix la informació d’un plat del menú.

        Mostra el nom del plat, el preu, la temporada i l’estil
        si existeix a la base de dades; en cas contrari,
        imprimeix només el nom.
        """

        if plat_case is None:
            print("   (Plat no disponible)\n")
            return
        nom = plat_case["Nom-plat"]
        filtrats = df_plats[df_plats["Nom-plat"] == nom]

        if filtrats.empty:
            # El plat no existeix a df_plats
            print(f"• {nom}")
            return

        fila = filtrats.iloc[0]

        print(f"• {nom} ({fila['Preu-plat']}€)")
        print(f"   Temporada: {fila['Temporada']}")
        print(f"   Estil: {fila['Estil-plat']}\n")

    def calcular_preu_menu_case(cas):
        """
        Calcula el preu total d’un menú.

        Suma el cost dels entrants (prorratejats per quart)
        i el preu complet del principal, segon i postres.
        Retorna 0 si el cas no existeix.
        """
        if cas is None:
            return 0
        total = 0.0
        plats = cas.plats
        if plats["entrants"]:
            for p in plats["entrants"]:
                fila = df_plats[df_plats["Nom-plat"] == p["Nom-plat"]].iloc[0]
                total += fila["Preu-plat"] / 4
        for key in ["principal", "segon", "postre"]:
            if plats[key]:
                fila = df_plats[df_plats["Nom-plat"] == plats[key]["Nom-plat"]].iloc[0]
                total += fila["Preu-plat"]
        return total

    # MODE TOP 3 
    if recom.get("es_top3", False):

        # Menú adults (TOP 3)
        if cas_adults is not None:

            print("\n" + "="*60)
            print("                 MENÚ ADULTS (TOP 3)")
            print("="*60)

            print(f"➡ Menú recomanat: {cas_adults.menu_id}\n")

            # Entrants
            if cas_adults.plats["entrants"]:
                print("ENTRANTS:")
                for p in cas_adults.plats["entrants"]:
                    print_plat_case(p)

            # Primer
            print("PRIMER PLAT:")
            print_plat_case(cas_adults.plats["principal"])

            # Segon
            print("SEGON PLAT:")
            print_plat_case(cas_adults.plats["segon"])

            # Postre
            print("POSTRE:")
            print_plat_case(cas_adults.plats["postre"])

            preu_menu_adults = calcular_preu_menu_case(cas_adults)
            print(f"\nPREU TOTAL MENÚ ADULTS: {preu_menu_adults:.2f} €\n")

        # Menú infantil (TOP 3)
        if cas_infantil is not None:

            print("\n" + "="*60)
            print("                 MENÚ INFANTIL (TOP 3)")
            print("="*60)
            print(f"➡ Menú recomanat: {cas_infantil.menu_id}\n")

            for key, title in [
                ("principal", "PRIMER PLAT"),
                ("segon", "SEGON PLAT"),
                ("postre", "POSTRE")
            ]:
                print(title + ":")
                print_plat_case(cas_infantil.plats[key])

            preu_menu_inf = calcular_preu_menu_case(cas_infantil)
            print(f"\nPREU TOTAL MENÚ INFANTIL: {preu_menu_inf:.2f} €\n")

        print("="*60 + "\n")
        return

    # Begudes, vins, costos
    # Begudes
    imprimir_begudes_generals()

    # Beguda especial
    if preferencies["beguda"].lower() == "maridatge":
        imprimir_maridatge(adults)
    else:
        imprimir_vins(preferencies["complexitat_adults"], adults)

    # Pastís de boda
    if preferencies["esdeveniment"].lower() == "boda":
        imprimir_pastis_boda(preferencies["complexitat_adults"], adults)
        if preferencies["complexitat_adults"].lower() == "alta":
            cost_pastis = 485.63
        elif preferencies["complexitat_adults"].lower() == "mitjana":
            cost_pastis = 241.50
        else:
            cost_pastis = 126.00
    else:
        cost_pastis = 0.0
    

def imprimir_top3(recom, preferencies, df_plats):
    """
    Imprimeix els 3 millors menús recomanats (adults i infantils).
    Utilitza imprimir_recomanacio() per no duplicar codi.
    """

    # Top 3 adults
    print("\n================= TOP 3 MENÚS ADULTS =================")

    for i, (cas, sim) in enumerate(recom["top3_adults"], start=1):
        print(f"\n********** MENÚ ADULTS #{i} — similitud {sim:.3f} **********\n")

        imprimir_recomanacio(
        {
            "cas_adults": cas,
            "sim_adults": sim,
            "cas_infantil": None,
            "sim_infantil": None,
            "es_top3": True           
        },
        preferencies,
        df_plats
    )

    # Top 3 infantil
    if recom["top3_infantil"]:
        print("\n================= TOP 3 MENÚS INFANTILS =================")

        for i, (cas, sim) in enumerate(recom["top3_infantil"], start=1):
            print(f"\n********** MENÚ INFANTIL #{i} — similitud {sim:.3f} **********\n")

            imprimir_recomanacio(
            {
                "cas_adults": None,
                "sim_adults": None,
                "cas_infantil": cas,
                "sim_infantil": sim,
                "es_top3": True          
            },
            preferencies,
            df_plats
        )
            
def imprimir_resum_general_menus(top3_adults, top3_infantil):
    """
    Mostra un resum sintètic dels menús recomanats.

    Inclou els plats principals dels TOP 3 menús
    per a adults i infantils.
    """

    print("\n" + "="*60)
    print("                RESUM GENERAL DE MENÚS")
    print("="*60 + "\n")

    # Adults (TOP 3)
    for idx, (cas, sim) in enumerate(top3_adults, start=1):

        print(f"MENÚ {idx} ADULTS ({cas.menu_id}):")
        print("  • Entrants:")

        # Entrants
        if cas.plats.get("entrants"):
            for e in cas.plats["entrants"]:
                print(f"      - {e['Nom-plat']}")
        else:
            print("      (No hi ha entrants)")

        # Principal
        principal = cas.plats.get("principal")
        if principal:
            print(f"  • Principal: {principal['Nom-plat']}")
        else:
            print("  • Principal: (No disponible)")

        # Segon
        segon = cas.plats.get("segon")
        if segon:
            print(f"  • Segon:     {segon['Nom-plat']}")
        else:
            print("  • Segon:     (No disponible)")

        # Postre
        postre = cas.plats.get("postre")
        if postre:
            print(f"  • Postre:    {postre['Nom-plat']}\n")
        else:
            print("  • Postre:    (No disponible)\n")

    # Infantil (TOP 3)
    if top3_infantil:
        for idx, (cas, sim) in enumerate(top3_infantil, start=1):

            print(f"MENÚ {idx} INFANTIL ({cas.menu_id}):")

            # Principal
            principal = cas.plats.get("principal")
            if principal:
                print(f"  • Principal: {principal['Nom-plat']}")
            else:
                print("  • Principal: (No disponible)")

            # Segon
            segon = cas.plats.get("segon")
            if segon:
                print(f"  • Segon:     {segon['Nom-plat']}")
            else:
                print("  • Segon:     (No disponible)")

            # Postre
            postre = cas.plats.get("postre")
            if postre:
                print(f"  • Postre:    {postre['Nom-plat']}\n")
            else:
                print("  • Postre:    (No disponible)\n")

    else:
        print("(No hi ha menús infantils)\n")

    print("="*60 + "\n")

# Bucle final: adaptació del menú
def gestionar_post_recomanacio(cas_adults, cas_infantil, preferencies, top3_adults, top3_infantil):
    """
    Permet adaptar qualsevol dels TOP3 menús (adults o infantils).
    Inclou:
      - Gestió completa d'exit/quit
      - Gestió completa de reset/restart
      - Recuperació de similars per substitució manual
    """

    # Recuperem similars per adults i infantil (per reuse)
    sims_adults = retrieve_best(preferencies, infantil=False)[1]

    if preferencies["menu_infantil"].lower() == "si":
        sims_infantil = retrieve_best(preferencies, infantil=True)[1]
    else:
        sims_infantil = []

    print("Vols canviar alguna cosa d’algun menú? (Si/No)")
    while True:
        resp = input("  >> ").strip().lower()

        if check_exit(resp):
            continue
        if check_reset(resp):
            return "__RESTART_ALL__"

        # No vol canviar → explicació llm
        if resp.startswith("n"):

            print("\nVols una explicació del perquè d'aquest menú? (Si/No)")
            r2 = input("  >> ").strip().lower()

            if r2.startswith("s"):
                from recomanador.llm_explicacio import generar_explicacio_llm

                # Afegit mínim per LLM
                menu_final = {
                    "entrants": [p["Nom-plat"] for p in cas_adults.plats.get("entrants", [])] if cas_adults else [],
                    "principal": cas_adults.plats.get("principal", {}).get("Nom-plat") if cas_adults else None,
                    "segon": cas_adults.plats.get("segon", {}).get("Nom-plat") if cas_adults else None,
                    "postre": cas_adults.plats.get("postre", {}).get("Nom-plat") if cas_adults else None,
                }

                dades_llm = {
                    "menu_id": cas_adults.menu_id if cas_adults else None,
                    "preferencies": preferencies,
                    "menu_final": menu_final,
                    "adaptacions": getattr(cas_adults, "adaptacions", [])
                }

                explicacio = generar_explicacio_llm(
                    dades_llm,
                    usar_llm_real=True
                )

                print("\n========== EXPLICACIÓ DEL MENÚ ==========")
                print(explicacio)
                print("========================================\n")

            print("\nMoltes gràcies per utilitzar RicoRico!")
            return

        if not resp.startswith("s"):
            print("Respon Si o No.")
            continue

        # Selecció de menú a modificar
        while True:
            print("\n================== SELECCIONA MENÚ A MODIFICAR ==================")
            idx_map = {}

            print("\nMENÚS ADULTS:")
            for i, (cas, sim) in enumerate(top3_adults, start=1):
                print(f"  {i}. {cas.menu_id} (sim={sim:.3f})")
                idx_map[str(i)] = ("adults", cas)

            if top3_infantil:
                print("\nMENÚS INFANTILS:")
                base = len(top3_adults)
                for j, (cas, sim) in enumerate(top3_infantil, start=1):
                    k = base + j
                    print(f"  {k}. {cas.menu_id} (sim={sim:.3f})")
                    idx_map[str(k)] = ("infantil", cas)

            print("\n  0. Cancel·lar selecció\n")
            sel = input("  >> ").strip()

            if user_wants_exit(sel):
                ask_exit_confirmation()
                continue

            if user_wants_reset(sel):
                if ask_restart_confirmation():
                    return "__RESTART_ALL__"
                else:
                    continue

            if sel == "0":
                print("Cancel·lat.")
                return

            if sel not in idx_map:
                print("Opció no vàlida.")
                continue

            from copy import deepcopy
            tipus_menu, cas_original = idx_map[sel]
            cas_seleccionat = deepcopy(cas_original)
            break

        # Opcions d’adaptació
        while True:
            print("\n================== OPCIONS D’ADAPTACIÓ ==================")
            print("1. Consultar / modificar ingredients d’un plat")
            print("2. Adaptar un plat segons l’estil del xef")
            print("3. Adaptar cultura culinària d’un plat")
            print("4. Substituir un plat per un altre del TOP similars")
            print("5. Adaptació per al·lèrgies")
            print("6. Finalitzar adaptació")
            print("=========================================================\n")

            op = input("  >> ").strip()

            if user_wants_exit(op):
                ask_exit_confirmation()
                continue

            if user_wants_reset(op):
                if ask_restart_confirmation():
                    return "__RESTART_ALL__"
                else:
                    continue

            if op == "6":
                break

            es_inf = (tipus_menu == "infantil")

            if op == "1":
                resultat = adaptar_consultar_modificar_ingredients_CASE(
                    cas_seleccionat if not es_inf else None,
                    cas_seleccionat if es_inf else None,
                    preferencies
                )

                if resultat in ("done", "__END__"):
                    return "__END__"
                if resultat == "__SELECT_ANOTHER_MENU__":
                    return "__SELECT_ANOTHER_MENU__"
                if resultat == "__RESTART_ALL__":
                    return "__RESTART_ALL__"
                continue

            elif op == "2":
                result = adaptar_estil_plat_MULTIPLE(
                    cas_seleccionat if not es_inf else None,
                    cas_seleccionat if es_inf else None,
                    preferencies
                )
                continue

            elif op == "3":
                result = adaptar_origen_plat_CASE(
                    cas_seleccionat,
                    df_plats,
                    cultures,
                    dicc_plat_ingredients,
                    preferencies=preferencies
                )


            elif op == "4":
                result = substituir_plat_CASE(
                    cas_seleccionat,
                    preferencies,
                    es_inf
                )


            elif op == "5":
                result = adaptar_per_allergies_MULTIPLE(
                    cas_seleccionat if not es_inf else None,
                    cas_seleccionat if es_inf else None,
                    preferencies
                )
            # 1) Canviar a un altre menú
            if result == "_SELECT_ANOTHER_MENU_":
                return "_SELECT_ANOTHER_MENU_"

            # 2) Tornar al menú d’adaptacions
            if result == "_BACK_TO_ADAPTATIONS_":
                continue

            # 3) Final correcte
            if result == "_FINISHED_SUCCESS_":
                return "_END_"

            # 4) Reiniciar tot
            if result == "_RESTART_ALL_":
                return "_RESTART_ALL_"

            # 5) Qualsevol altre cas → tornar al menú d’opcions
            continue

        # Final → Explicació menú final
        print("\nAdaptació finalitzada!\n")
        print("Vols una explicació del perquè del menú final? (Si/No)")
        r2 = input("  >> ").strip().lower()

        if r2.startswith("s"):
            from recomanador.llm_explicacio import generar_explicacio_llm

            menu_final = {
                "entrants": [p["Nom-plat"] for p in cas_seleccionat.plats.get("entrants", [])],
                "principal": cas_seleccionat.plats.get("principal", {}).get("Nom-plat"),
                "segon": cas_seleccionat.plats.get("segon", {}).get("Nom-plat"),
                "postre": cas_seleccionat.plats.get("postre", {}).get("Nom-plat"),
            }

            dades_llm = {
                "menu_id": cas_seleccionat.menu_id,
                "preferencies": preferencies,
                "menu_final": menu_final,
                "adaptacions": getattr(cas_seleccionat, "adaptacions", [])
            }

            explicacio = generar_explicacio_llm(
                dades_llm,
                usar_llm_real=True
            )

            print("\n========== EXPLICACIÓ DEL MENÚ ==========")
            print(explicacio)
            print("========================================\n")

        return


def seleccionar_menu_i_adaptar(top3_adults, top3_infantil, preferencies):
    """
    Permet seleccionar un altre menú recomanat (dels TOP3) i adaptar-lo.
    Retorna:
      - "__SELECT_ANOTHER_MENU__" si l’usuari vol seguir adaptant altres menús
      - "__RESTART_ALL__" si vol reiniciar tot
      - None si acaba la fase d’adaptació
    """

    while True:

        print("\n================== SELECCIONA MENÚ A MODIFICAR ==================")
        idx_map = {}

        print("\nMENÚS ADULTS:")
        for i, (cas, sim) in enumerate(top3_adults, start=1):
            print(f"  {i}. {cas.menu_id} (sim={sim:.3f})")
            idx_map[str(i)] = ("adults", cas)

        if top3_infantil:
            print("\nMENÚS INFANTILS:")
            base = len(top3_adults)
            for j, (cas, sim) in enumerate(top3_infantil, start=1):
                k = base + j
                print(f"  {k}. {cas.menu_id} (sim={sim:.3f})")
                idx_map[str(k)] = ("infantil", cas)

        print("\n  0. Cancel·lar selecció\n")
        sel = input("  >> ").strip()

        if user_wants_exit(sel):
            ask_exit_confirmation()
            continue

        if user_wants_reset(sel):
            if ask_restart_confirmation():
                return "__RESTART_ALL__"
            else:
                continue

        if sel == "0":
            print("Cancel·lat.")
            return None

        if sel not in idx_map:
            print("Opció no vàlida.")
            continue

        from copy import deepcopy
        tipus_menu, cas_original = idx_map[sel]
        cas_seleccionat = deepcopy(cas_original)

        break

    # Determinar similars segons adults/infantil
    if tipus_menu == "adults":
        similars = [(c, s) for (c, s) in top3_adults]
    else:
        similars = [(c, s) for (c, s) in top3_infantil]

    # Bucle d'adaptació del menú seleccionat
    while True:
        print("\n================== OPCIONS D’ADAPTACIÓ ==================")
        print("1. Consultar / modificar ingredients d’un plat")
        print("2. Adaptar un plat segons l’estil del xef")
        print("3. Adaptar cultura culinària d’un plat")
        print("4. Substituir un plat per un altre del TOP similars")
        print("5. Adaptació per al·lèrgies")
        print("6. Finalitzar adaptació")
        print("=========================================================\n")

        op = input("  >> ").strip()

        # exit/reset acceptats
        if user_wants_exit(op):
            ask_exit_confirmation()
            continue

        if user_wants_reset(op):
            if ask_restart_confirmation():
                return "__RESTART_ALL__"
            else:
                continue

        if op == "6":
            break

        es_inf = (tipus_menu == "infantil")

        # Ingredients
        if op == "1":
            adaptar_consultar_modificar_ingredients_CASE(
                cas_seleccionat if not es_inf else None,
                cas_seleccionat if es_inf else None,
                preferencies
            )
            continue

        # Estil del xef
        elif op == "2":
            resultat = adaptar_estil_plat_MULTIPLE(
                cas_seleccionat if not es_inf else None,
                cas_seleccionat if es_inf else None,
                preferencies
            )

            if resultat == "__BACK_TO_ADAPTATIONS__":
                continue

            if resultat == "__SELECT_ANOTHER_MENU__":
                return "__SELECT_ANOTHER_MENU__"

            if resultat == "__FINISHED_SUCCESS__":
                return "__END__"

            if resultat == "__RESTART_ALL__":
                return "__RESTART_ALL__"

            continue

        # Cultura
        elif op == "3":
            resultat = adaptar_origen_plat_CASE(
                cas_seleccionat,
                plats=df_plats,
                cultures=cultures,
                dicc_plat_ingredients=dicc_plat_ingredients,
                preferencies=preferencies
            )

            if resultat == "__BACK_TO_ADAPTATIONS__":
                continue

            if resultat == "__SELECT_ANOTHER_MENU__":
                return "__SELECT_ANOTHER_MENU__"

            if resultat == "__FINISHED_SUCCESS__":
                return "__END__"

            if resultat == "__RESTART_ALL__":
                return "__RESTART_ALL__"

            continue

        # Substitució
        elif op == "4":
            resultat = substituir_plat_CASE(
                cas_seleccionat,
                preferencies,
                es_inf
            )

            if resultat == "__BACK_TO_ADAPTATIONS__":
                continue

            if resultat == "__SELECT_ANOTHER_MENU__":
                return "__SELECT_ANOTHER_MENU__"

            if resultat == "__FINISHED_SUCCESS__":
                return "__END__"

            if resultat == "__RESTART_ALL__":
                return "__RESTART_ALL__"

            continue

        # Al·lèrgies
        elif op == "5":
            resultat = adaptar_per_allergies_MULTIPLE(
                cas_seleccionat if not es_inf else None,
                cas_seleccionat if es_inf else None,
                preferencies
            )

            # Sense canvis
            if resultat is False:
                print("No s'ha aplicat cap canvi en aquest plat.\n")
                continue

            # Ja guardat
            if resultat == "__FINISHED_AND_SAVED__":
                print("\nMenú adaptat i guardat correctament.")
                return None # tornem al selector principal

            # Canvis però no guardat
            if resultat == "__FINISHED_NOT_SAVED__":
                print("\nAdaptació per al·lèrgies finalitzada (no guardat).")
                continue

        else:
            print("Opció no vàlida.")

    # Resultat
    print("\nAdaptació finalitzada!\n")
    
    return None

def imprimir_plats_menu(cas):
    """
    Imprimeix els plats disponibles d’un menú.

    Retorna una llista ordenada de plats per facilitar
    la selecció posterior.
    """

    print("\n==================== PLATS DISPONIBLES ====================\n")

    llista = []
    for tipus in ["entrants", "principal", "segon", "postre"]:
        plats = cas.plats.get(tipus)
        if tipus == "entrants" and plats:
            for p in plats:
                llista.append((tipus.capitalize(), p))
        else:
            llista.append((tipus.capitalize(), plats))

    for i, (tipus, plat) in enumerate(llista, 1):
        print(f"  {i}. {tipus}: {plat['Nom-plat']}")

    print("===========================================================\n")
    return llista