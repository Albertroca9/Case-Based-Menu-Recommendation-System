# recomanador/adaptacio_chef.py

"""
Adaptació de plats segons l’estil d’un xef.

Aquest mòdul implementa l’adaptació d’un o més plats d’un menú
a l’estil culinari d’un xef, modificant tècniques, sabors i ingredients
de manera coherent, validant el resultat i guardant el cas adaptat
amb feedback dins del sistema CBR.
"""

# Imports
from cbr.retain import retain_cas
from cbr.revise import revisar_cas
from data.carrega_dades import df_plats
from data.carrega_dades import chefs, dicc_plat_ingredients, ingredients
from utils.helpers import is_no, is_yes, normalitza_camelcase, RESET, BOLD, normalize_text
from data.carrega_dades import chefs, dicc_plat_ingredients, ingredients, dicc_principal
import copy
import re

PES_CLASSE = {
    "Carn": 3,
    "Peix": 3,
    "Marisc": 3,
    "Vegetal": 2,
    "Fruita": 2,
    "Gra": 2,
    "Cereal": 2,
    "Llegum": 2,
    "Herba": 1,
    "Espècia": 1,
    "Altres": 1,
}

def nom_real(ing_norm):
    """
    Retorna el nom real (original) d’un ingredient a partir del seu nom normalitzat.

    Cerca l’ingredient dins del conjunt d’ingredients coneguts i,
    si el troba, en retorna el nom original; en cas contrari,
    retorna el nom normalitzat.
    """

    ing_norm = normalitza_camelcase(ing_norm)

    # Matching per normalització
    for x in ingredients["Nom-ingredient"]:
        if normalitza_camelcase(x) == ing_norm:
            return x

    return ing_norm

def detectar_regio_principal(ing_actuals):
    """
    Detecta la regió gastronòmica principal d’un plat.

    Calcula una puntuació per regió a partir dels ingredients del plat,
    ponderant-los segons la seva classe, i retorna la regió dominant.
    En cas d’empat, aplica criteris de desempat simples.
    """
        
    puntuacions = {}

    for ing in ing_actuals:
        fila = ingredients[ingredients["Nom-ingredient"] == ing]
        if fila.empty:
            continue

        classe = fila["Classe"].iloc[0]
        regio = fila["Tipic-de"].iloc[0]

        pes = PES_CLASSE.get(classe, 1)
        puntuacions[regio] = puntuacions.get(regio, 0) + pes

    if not puntuacions:
        return "Global"

    ordenat = sorted(puntuacions.items(), key=lambda x: -x[1])
    millor, punts = ordenat[0]
    empatats = [r for r, p in puntuacions.items() if p == punts]

    if len(empatats) == 1:
        return millor

    if "Mediterrani" in empatats:
        return "Mediterrani"
    if "Europa" in empatats:
        return "Europa"

    return empatats[0]

# Funcions auxiliars
def parse_llista(text):
    """
    Converteix un text separat per comes en una llista normalitzada.

    Retorna una llista d’elements en format normalitzat i elimina
    espais en blanc o valors buits.
    """

    if not isinstance(text, str):
        return []
    return [normalitza_camelcase(x.strip()) for x in text.split(",") if x.strip()]


def obtenir_combina_amb(ingredient):
    """
    Retorna els ingredients amb què un ingredient combina habitualment.

    Consulta la informació del domini i retorna un conjunt d’ingredients
    compatibles segons el camp «Combina-amb». Si no hi ha dades,
    retorna un conjunt buit.
    """

    try:
        fila = ingredients[ingredients["Nom-ingredient"] == ingredient].iloc[0]
        parts = [normalitza_camelcase(x.strip()) for x in str(fila["Combina-amb"]).split(",") if x.strip()]
        return set(parts)
    except:
        return set()


def ingredient_te_sentit(ing, ing_base):
    """
    Comprova si un ingredient és coherent amb una base d’ingredients.

    Retorna True si l’ingredient combina amb algun dels ingredients
    base segons les relacions de compatibilitat definides.
    """

    ing = normalitza_camelcase(ing)
    for base in ing_base:
        if ing in obtenir_combina_amb(base):
            return True
    return False

#Filtratge coherència
def filtrar_ingredients_coherents_principal(candidats, ing_base, principal=None, regio_detectada=None):
    """
    Filtra ingredients candidats segons la seva coherència amb el plat principal.

    Avalua la compatibilitat amb l’ingredient principal, la regió gastronòmica
    dominant i les classes d’ingredients del plat, retornant els candidats
    més coherents ordenats per prioritat.
    """

    bons = []

    if principal is None:
        return []

    if regio_detectada is None:
        regio_detectada = "Global"

    combina_principal = obtenir_combina_amb(principal)

    classes_base = []
    for ing in ing_base:
        fila = ingredients[ingredients["Nom-ingredient"] == ing]
        if not fila.empty:
            classes_base.append(fila["Classe"].iloc[0])

    for c in candidats:
        c_norm = normalitza_camelcase(c)
        if c_norm not in combina_principal:
            continue
        combina_extra = any(
            c_norm in obtenir_combina_amb(b)
            for b in ing_base
        )
        fila = ingredients[ingredients["Nom-ingredient"] == c_norm]

        penalitzacio = 0

        if not fila.empty:
            regio_c = fila["Tipic-de"].iloc[0]
            classe_c = fila["Classe"].iloc[0]

            if regio_c != regio_detectada:
                penalitzacio += 1

            if ("Peix" in classes_base or "Marisc" in classes_base) and classe_c == "Carn":
                penalitzacio += 3

        # score final
        score = (2 if combina_extra else 1) - penalitzacio

        if score > 0:
            bons.append((c_norm, score))

    # Ordenem millor primer
    bons = sorted(bons, key=lambda x: -x[1])

    return [b[0] for b in bons]


def ingredients_representatius_per_sabor(ingredients_df):
    """
    Agrupa ingredients representatius segons el seu sabor principal.

    Retorna un diccionari que associa cada sabor amb una llista
    d’ingredients que el representen.
    """

    mapping = {}
    for _, fila in ingredients_df.iterrows():
        nom = normalitza_camelcase(fila["Nom-ingredient"])
        for part in str(fila["Sabor"]).split(","):
            s = normalitza_camelcase(part.strip())
            if s:
                mapping.setdefault(s, []).append(nom)
    return mapping

def ingredients_generals_per_sabor(sabor, ingredients_df):
    """
    Retorna ingredients associats a un sabor determinat.

    Filtra els ingredients del domini que contenen el sabor indicat
    i retorna els seus noms normalitzats.
    """

    sabor = normalitza_camelcase(sabor)
    filt = ingredients_df[ingredients_df["Sabor"].str.contains(sabor, na=False)]
    return [normalitza_camelcase(x) for x in filt["Nom-ingredient"].tolist()]

def sabors_de_ingredient(ing):
    """
    Retorna la llista de sabors associats a un ingredient.

    Consulta la informació del domini i extreu els sabors definits
    per a l’ingredient indicat.
    """

    ing_norm = normalitza_camelcase(ing)
    matching = ingredients[ingredients["Nom-ingredient"] == ing_norm]
    if matching.empty:
        return []
    fila = matching.iloc[0]
    return parse_llista(fila["Sabor"])

# Compatiblitat sabors
COMPATIBILITAT_SABORS = {
    "Fresc": {"Acid": 2, "Herbaci": 2, "Aquos": 2, "Cremos": 1, "Dolc": 1, "Torrat": -1, "Fumat": -2},
    "Acid": {"Fresc": 2, "Dolc": 2, "Herbaci": 1, "Cremos": -1, "Fumat": -2},
    "Herbaci": {"Fresc": 2, "Acid": 1, "Cremos": 1, "Torrat": -1, "Fumat": -2},
    "Cremos": {"Dolc": 2, "Umami": 1, "Fresc": 1, "Acid": -1},
    "Umami": {"Torrat": 2, "Sali": 2, "Fumat": 2, "Dolc": -1},
    "Torrat": {"Umami": 2, "Fumat": 1, "Aquos": -2, "Fresc": -1},
    "Fumat": {"Umami": 2, "Torrat": 1, "Fresc": -2, "Acid": -2},
    "Dolc-suau": {"Acid": 2, "Fresc": 1, "Fumat": -1},
}

def puntuacio_coherencia_sabors(sabors, compat=COMPATIBILITAT_SABORS):
    """
    Calcula una puntuació de coherència entre un conjunt de sabors.

    Avalua la compatibilitat parell a parell segons una matriu
    de compatibilitat i retorna una puntuació global.
    """

    score = 0
    sabors = list(dict.fromkeys(sabors))

    for i in range(len(sabors)):
        for j in range(i + 1, len(sabors)):
            s1 = sabors[i]
            s2 = sabors[j]

            if s1 in compat and s2 in compat[s1]:
                score += compat[s1][s2]
                continue
            if s2 in compat and s1 in compat[s2]:
                score += compat[s2][s1]
                continue

    return score

def es_coherent_afegir(sabors_actuals, sabors_a_afegir):
    """
    Comprova si afegir nous sabors manté o millora la coherència global.

    Retorna True si la puntuació de coherència després d’afegir
    els nous sabors és igual o superior a l’original.
    """

    score_abans = puntuacio_coherencia_sabors(sabors_actuals)
    score_despres = puntuacio_coherencia_sabors(sabors_actuals + sabors_a_afegir)
    return score_despres >= score_abans

# Adaptació completa a l'estil d'un xef
def adaptar_estil_plat_CASE(cas_adults, cas_infantil, menu_actual=None, preferencies=None):
    """
    Adapta un plat d’un menú a l’estil d’un xef concret.

    Permet seleccionar un plat del menú (adults o infantil), aplicar-hi
    les tècniques, sabors i ingredients característics d’un xef,
    mantenint la coherència gastronòmica, i genera un nou menú adaptat.
    
    Retorna el plat adaptat i el nou menú resultant.
    """
        
    print("\n==================== ADAPTACIÓ D'ESTIL (CHEF) ====================")
    # Si venim d’una adaptació prèvia, treballarem sobre el menú actual
    if menu_actual is not None:
        cas = menu_actual
    else:
        if cas_adults is not None and not getattr(cas_adults, "es_infantil", False):
            cas = cas_adults
        elif cas_infantil is not None and getattr(cas_infantil, "es_infantil", False):
            cas = cas_infantil
        else:
            print("No s'ha pogut determinar si el menú és d'adults o infantil.")
            print("Això no hauria de passar: revisa com envies cas_adults/cas_infantil.")
            return None, None

    # Triar plat
    llista = []
    for tipus in ["entrants", "principal", "segon", "postre"]:
        plats = cas.plats.get(tipus)
        if tipus == "entrants" and plats:
            for p in plats:
                llista.append(("Entrant", p))
        elif plats:
            llista.append((tipus.capitalize(), plats))

    print("\nPlats disponibles:")
    for i, (t, p) in enumerate(llista, 1):
        print(f"  {i}. {t}: {p['Nom-plat']}")

    while True:
        op = input("\nQuin plat vols adaptar? (número)\n  >> ").strip()
        if op.isdigit() and 1 <= int(op) <= len(llista):
            tipus_sel, plat_sel = llista[int(op)-1]
            break
        print("Número no vàlid.")

    nom_original = plat_sel["Nom-plat"]
    
    ing_actuals = dicc_plat_ingredients.get(nom_original, set())
    ingredients_base_norm = { normalitza_camelcase(ing) for ing in ing_actuals }
    tecn_actuals = parse_llista(plat_sel.get("Tecniques", ""))
    sabors_actuals = parse_llista(plat_sel.get("Sabor", ""))

    # Triar xef
    print("\nQuin estil de xef vols aplicar?\n")
    noms_chefs = chefs["Chef"].tolist()

    for i, nomchef in enumerate(noms_chefs, 1):
        estil = chefs.loc[chefs["Chef"] == nomchef, "Estil"].iloc[0]
        print(f"  {i}. {nomchef} – {estil}")

    while True:
        op2 = input("  >> ").strip()

        # Validació bàsica
        if op2.isdigit() and 1 <= int(op2) <= len(noms_chefs):
            chef_sel = noms_chefs[int(op2)-1]

            # Evitar aplicar el mateix xef dues vegades al mateix plat
            nom_lower = nom_original.lower()
            estil_lower = f"(estil {chef_sel.lower()})"

            if estil_lower in nom_lower:
                print(f"\n Aquest plat ja està adaptat a l’estil de {chef_sel}.")
                print(" Si us plau, tria un altre xef.\n")
                continue  

            break

        print("Número incorrecte.")

    fila_chef = chefs[chefs["Chef"] == chef_sel].iloc[0]

    tecn_chef     = parse_llista(fila_chef["Tecniques"])
    ing_clau_chef = parse_llista(fila_chef["Ingredients-clau"])
    sabors_chef   = parse_llista(fila_chef["Sabors"])

    # Obtenir principal i regió 
    nom_norm = normalitza_camelcase(nom_original)
    principal = dicc_principal.get(nom_norm, None)
    regio_detectada = detectar_regio_principal(ing_actuals)
    
    # Adaptació de tècniques
    mapping_tecn = {
        "Amanir": ["Amanir", "Aromatitzar", "Marinar", "Cocció àcida", "Airejar", "Infusionar", "Encurtir"],
        "Arrebossar": ["Fregir", "Forn cruixent", "Gratinar", "Planxar", "Saltejat agressiu"],
        "Baixa temperatura": ["Cocció al buit", "Cocció lenta", "Confitar", "Vapor", "Deshidratar"],
        "Batre": ["Emulsionar", "Fer escuma", "Airejar", "Texturitzar"],
        "Brasejar": ["Rostir", "Marcar", "Sellar","Ahumar", "Fumat"],
        "Bullir": ["Vapor", "Blanquejar", "Cocció lenta", "Reducció"],
        "Caramel·litzar": ["Glassejar", "Reduir", "Reducció", "Desglasar"],
        "Confitar": ["Baixa temperatura", "Cocció lenta", "Cocció al buit"],
        "Vapor": ["Blanquejar", "Cocció lenta"],
        "Emulsionar": ["Fer escuma", "Airejar", "Texturitzar", "Amanir"],
        "Enfornar": ["Gratinar", "Deshidratar", "Rostir", "Cocció lenta"],
        "Escaldar": ["Blanquejar", "Vapor", "Bullir"],
        "Estofar": ["Guissar", "Cocció lenta", "Brasejar"],
        "Fer escuma": ["Emulsionar", "Airejar", "Texturitzar"],
        "Fregir": ["Saltejar", "Wok", "Saltejat agressiu", "Planxar", "Marcar", "Sellar"],
        "Fumat": ["Ahumar", "Ahumar lleuger", "Brasejar"],
        "Gelificar": ["Esferificació", "Texturitzar", "Fer escuma"],
        "Gratinar": ["Enfornar", "Glassejar"],
        "Guissar": ["Estofar", "Cocció lenta", "Brasejar"],
        "Infusionar": ["Aromatitzar", "Amanir", "Destil·lació aromàtica", "Cocció lenta"],
        "Laminar": ["Tallar fi", "Tallar en juliana", "Tallar en brunoise"],
        "Marinar": ["Cocció àcida", "Amanir", "Encurtir", "Aromatitzar"],
        "Picar": ["Triturar", "Tallar fi", "Laminar"],
        "Planxar": ["Sellar", "Marcar", "Saltejat agressiu", "Brasejar"],
        "Reducció": ["Reducció lenta", "Desglasar", "Glassejar"],
        "Remenar": ["Emulsionar", "Airejar", "Texturitzar"],
        "Rostir": ["Brasejar", "Cocció lenta", "Enfornar"],
        "Saltejar": ["Wok", "Saltejat agressiu", "Planxar"],
        "Sellar": ["Marcar", "Planxar", "Brasejar"],
        "Sofregir": ["Saltejar", "Estofar", "Aromatitzar"],
        "Tallar en brunoise": ["Tallar fi", "Tallar en juliana"],
        "Tallar en daus": ["Tallar en brunoise", "Tallar fi", "Tallar en mirepoix"],
        "Tallar en juliana": ["Laminar", "Tallar fi"],
        "Tallar en mirepoix": ["Tallar en brunoise", "Tallar fi"],
        "Temperar": ["Atemperar", "Texturitzar"],
        "Triturar": ["Texturitzar", "Airejar", "Fer escuma"],
    }

    # Normalització 
    def norm_tecnica(t):
        """
        Normalitza el nom d’una tècnica culinària.

        Unifica el format del text eliminant símbols, guions i diferències
        de majúscules per facilitar comparacions i substitucions.
        """

        return normalitza_camelcase(
            t.replace("-", " ").replace("_", " ").strip()
        )

    # Normalitzar dades
    tecn_actuals_norm = [norm_tecnica(t) for t in tecn_actuals]
    tecn_chef_norm    = [norm_tecnica(t) for t in tecn_chef]

    # Normalitzar mapping
    mapping_tecn_norm = {
        norm_tecnica(k): [norm_tecnica(v) for v in vals]
        for k, vals in mapping_tecn.items()
    }

    # Substitució 
    def substituir_tecnica(tecnica):
        """
        Substitueix una tècnica original per una tècnica coherent amb el xef.

        Si existeix una tècnica equivalent dins de les tècniques pròpies
        del xef seleccionat, la retorna; en cas contrari, manté la tècnica original.
        """

        t = norm_tecnica(tecnica)
        if t not in mapping_tecn_norm:
            return t
        substituts = mapping_tecn_norm[t]
        valids = [s for s in substituts if s in tecn_chef_norm]
        if valids:
            return valids[0]
        return t

    # Aplicar substitució a tot el plat 
    noves_tecn = [substituir_tecnica(t) for t in tecn_actuals_norm]

    # Eliminar duplicats mantenint ordre
    noves_tecn = list(dict.fromkeys(noves_tecn))

    # Adaptació de sabors
    noves_sabors = list(dict.fromkeys(sabors_actuals + sabors_chef))

    mapa_sabor_per_tec = {

        "Ahumar": ["Fumat", "Intens"],
        "Airejar": ["Fresc", "Suau"],
        "Amanir": ["Fresc", "Acid", "Herbaci", "Citric"],
        "Aromatitzar": ["Herbaci", "Fresc"],
        "BaixaTemperatura": ["Suau", "Cremos"],
        "Blanquejar": ["Fresc", "Aquos"],
        "Brasejar": ["Umami", "Intens", "Terros", "Torrat"],
        "Bullir": ["Aquos", "Suau"],
        "Caramellitzar": ["Dolc", "Dolc-suau", "Torrat", "Amarg-suau"],
        "CoccioAlBuit": ["Suau", "Cremos"],
        "CoccioLenta": ["Suau", "Cremos", "Umami"],
        "CoccioAcida": ["Acid", "Citric"],
        "Confitar": ["Cremos", "Dolc-suau", "Suau"],
        "Desglasar": ["Umami", "Intens"],
        "Deshidratar": ["Intens", "Torrat"],
        "DeshidratarNaturalment": ["Intens"],
        "DestillacioAromatica": ["Fresc", "Herbaci"],
        "Emulsionar": ["Cremos", "Suau"],
        "Encurtir": ["Acid", "Citric", "PicantSuau"],
        "Enfornar": ["Torrat", "Amarg-suau"],
        "Esferificacio": ["Suau", "Cremos"],
        "Estofar": ["Umami", "Terros", "Cremos"],
        "FerEscuma": ["Cremos", "Fresc", "Suau"],
        "FerFermentacio": ["Acid", "PicantSuau"],
        "Fermentacio": ["Acid", "PicantSuau"],
        "Fregir": ["Torrat", "Intens", "Amarg-suau", "Sali"],
        "Fumat": ["Fumat", "Intens"],
        "Gelificar": ["Suau", "Cremos"],
        "Glassejar": ["Dolc-suau", "Torrat"],
        "Gratinar": ["Torrat", "Dolc-suau", "Amarg-suau"],
        "Guissar": ["Umami", "Terros", "Cremos"],
        "Infusionar": ["Herbaci", "Fresc"],
        "Laminar": ["Fresc", "Suau"],
        "Marcar": ["Torrat", "Intens"],
        "Marinar": ["Acid", "Citric", "Fresc"],
        "Picar": ["Intens", "Fresc"],
        "Planxar": ["Torrat", "Intens"],
        "Reduccio": ["Intens", "Sali", "Umami", "Dolc"],
        "ReduccioLenta": ["Intens", "Umami"],
        "Reduir": ["Intens", "Umami", "Dolc"],
        "Rostir": ["Torrat", "Intens", "Amarg-suau"],
        "Saltejar": ["Umami", "Torrat", "Fresc"],
        "SaltejatAgressiu": ["Torrat", "Intens"],
        "Sellar": ["Torrat", "Intens"],
        "Sofregir": ["Umami", "Torrat", "Sali"],
        "TallarEnBrunoise": ["Fresc"],
        "TallarEnJuliana": ["Fresc", "Herbaci"],
        "TallarFi": ["Fresc"],
        "Temperar": ["Cremos", "Suau"],
        "Texturitzar": ["Cremos", "Suau", "Fresc"],
        "Triturar": ["Cremos", "Fresc", "Suau"],
        "Vapor": ["Fresc", "Aquos", "Suau"],
        "Wok": ["Torrat", "Intens", "Umami"],
    }

    mapa_sabor_per_tec = {
        norm_tecnica(k): [normalitza_camelcase(s) for s in v]
        for k, v in mapa_sabor_per_tec.items()
    }

    # Actualitzar sabors segons tècniques existents
    for t in noves_tecn:
        if t in mapa_sabor_per_tec:
            for s in mapa_sabor_per_tec[t]:
                s_norm = normalitza_camelcase(s)
                if s_norm not in noves_sabors:
                    noves_sabors.append(s_norm)

    # Afegir ingredients coherents
    ingredients_final = list(ing_actuals)
    afegits_per_sabor = []

    MAX_TOTAL = 4
    total_afegits = 0

    for sabor in sabors_chef:

        if total_afegits >= MAX_TOTAL:
            break

        candidats = ingredients_generals_per_sabor(sabor, ingredients)

        bons = filtrar_ingredients_coherents_principal(
            candidats,
            ing_actuals,
            principal,
            regio_detectada
        )
        if not bons:
            continue

        ing = bons[0]
        ing_norm = normalitza_camelcase(ing)
        if ing_norm in ingredients_base_norm:
            continue
        if preferencies and "ingredients_prohibits" in preferencies:
            if ing in preferencies["ingredients_prohibits"]: 
                print(f"Ingredient prohibit descartat: {ing}")
                continue

        sabs_ing = sabors_de_ingredient(ing)

        # comprovem coherència
        if es_coherent_afegir(noves_sabors, sabs_ing):
            ingredients_final.append(ing)
            ingredients_base_norm.add(ing_norm)
            afegits_per_sabor.append(ing)
            total_afegits += 1
            for s in sabs_ing:
                if s not in noves_sabors:
                    noves_sabors.append(s)
        else:
            print(f"Ingredient descartat per baixa coherència de sabor: {ing}")


    # Reforçar sabors
    tecniques_afegides = []

    for sabor in sabors_chef:
        s_norm = normalitza_camelcase(sabor)

        # Tècniques que generen aquest sabor segons el mapa
        tecniques_que_generen = [
            t for t, sabors_t in mapa_sabor_per_tec.items()
            if s_norm in sabors_t
        ]

        # Filtrar només tècniques que siguin del xef
        tecniques_del_chef_que_generen = [
            t for t in tecniques_que_generen
            if t in tecn_chef_norm
        ]

        # Afegir només les tècniques que no estiguin al plat
        for tec in tecniques_del_chef_que_generen:
            if tec not in noves_tecn:
                sabors_tec = mapa_sabor_per_tec.get(tec, [])
                sabors_tec_norm = [normalitza_camelcase(s) for s in sabors_tec]
                if es_coherent_afegir(noves_sabors, sabors_tec_norm):
                    noves_tecn.append(tec)
                    tecniques_afegides.append(tec)

                    # afegim sabors al model actual
                    for s in sabors_tec_norm:
                        if s not in noves_sabors:
                            noves_sabors.append(s)

    # Eliminar duplicats mantenint ordre
    noves_tecn = list(dict.fromkeys(noves_tecn))

    # Actualitzar plat
    plat_sel["Nom-plat"] = f"{nom_original} (estil {chef_sel})"
    plat_sel["Tecniques"] = ", ".join(noves_tecn)
    plat_sel["Sabor"] = ", ".join(noves_sabors)

    # Guardar una còpia del plat modificat
    plat_modificat_per_print = copy.deepcopy(plat_sel)

    plat_nou = copy.deepcopy(plat_sel)

    # Nom nou
    nom_nou_plat = f"{nom_original} (estil {chef_sel})"
    plat_nou["Nom-plat"] = nom_nou_plat

    # Reconstrucció dels ingredients del plat
    ingredients_4p_text = plat_sel.get("Ingredients-4p", "").strip()

    ingredients_obj = []

    for chunk in re.split(r"[,;]+", ingredients_4p_text):
        part = chunk.strip()
        if not part:
            continue

        match = re.match(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]+)\s+(.+)", part)

        if match:
            quant = float(match.group(1))
            unit = match.group(2).lower()
            nom = nom_real(match.group(3).strip())

            ingredients_obj.append({
                "nom": nom,
                "quantitat": quant,
                "unitat": unit
            })

        else:
            # Casos sense quantitat
            nom = nom_real(part)
            ingredients_obj.append({
                "nom": nom,
                "quantitat": "-",
                "unitat": "-"
            })

    originals_noms = set([ing["nom"] for ing in ingredients_obj])

    for ing in ingredients_final:
        nom_final = nom_real(ing)

        if nom_final not in originals_noms:
            ingredients_obj.append({
                "nom": nom_final,
                "quantitat": "-",
                "unitat": "-"
            })
            originals_noms.add(nom_final)

    ingredients_4p_str = ", ".join([
        f"{ing['quantitat']} {ing['unitat']} {ing['nom']}"
        if ing["quantitat"] != "-" else ing["nom"]
        for ing in ingredients_obj
    ])

    plat_nou["Ingredients-4p"] = ingredients_4p_str
    plat_nou["Tecniques"] = ", ".join(noves_tecn)
    plat_nou["Sabor"] = ", ".join(noves_sabors)

    origen_chef = fila_chef.get("Origen", None)
    if origen_chef:
        plat_nou["Origen"] = origen_chef
    plat_nou["Estil"] = chef_sel

    # Crear menú nom amb plat
    nou_menu = copy.deepcopy(cas)

    for tipus in ["entrants", "principal", "segon", "postre"]:
        plats_tipus = nou_menu.plats.get(tipus)

        # Entrants
        if tipus == "entrants":
            for i, p in enumerate(plats_tipus):
                if nom_original in p["Nom-plat"]:
                    nou_menu.plats[tipus][i] = plat_nou

        # Resta
        else:
            p = plats_tipus
            if nom_original in p["Nom-plat"]:
                nou_menu.plats[tipus] = plat_nou

    # Generar menú 
    menu_id_original = cas.menu_id

    if cas.es_infantil: 
        # Buscar tots els menu_id tipus "MenuInfX"
        menus_infantils = df_plats[df_plats["Tipus-public"] == "Nens"]["Menu"].unique()
        nums = []

        for m in menus_infantils:
            match = re.match(r"MenuInf(\d+)", m)
            if match:
                nums.append(int(match.group(1)))

        nou_num = max(nums) + 1 if nums else 1
        nou_menu_id = f"MenuInf{nou_num}"

    else: # Adults
        menus_adults = df_plats[df_plats["Tipus-public"] == "AdultsNens"]["Menu"].unique()
        nums = []

        for m in menus_adults:
            match = re.match(r"Menu(\d+)", m)
            if match:
                nums.append(int(match.group(1)))

        nou_num = max(nums) + 1 if nums else 1
        nou_menu_id = f"Menu{nou_num}"

    # Assignem el nou ID
    nou_menu.menu_id = nou_menu_id

    # Substitucions
    substitucions = []
    for i in range(min(len(tecn_actuals), len(noves_tecn))):
        orig = tecn_actuals[i]
        nou = noves_tecn[i]
        if orig != nou:
            substitucions.append((orig, nou))

    detalls_per_sabor = [(ing, sabors_de_ingredient(ing)) for ing in afegits_per_sabor]

    detalls_chef_complets = [(ing, sabors_de_ingredient(ing)) for ing in ing_clau_chef]

    # Resultat final
    print("\n==================== ADAPTACIÓ COMPLETA DEL PLAT ====================\n")
    print(f"{BOLD}NOM{RESET}")
    print(f"{plat_nou['Nom-plat']}\n")
    print(f"{BOLD}TÈCNIQUES{RESET}")
    print(f"Plat original: {', '.join(tecn_actuals)}")
    print(f"Característiques del xef: {', '.join(tecn_chef)}")
    print(f"Plat adaptat: {', '.join(noves_tecn)}\n")

    print("Afegides per reforçar sabors:")
    if tecniques_afegides:
        for t in tecniques_afegides:
            # Sabors que aporta la tècnica
            sabs = mapa_sabor_per_tec.get(t, [])
            sabs_norm = [normalitza_camelcase(s) for s in sabs]

            # Filtrar només sabors del xef
            sabors_chef_norm = [normalitza_camelcase(s) for s in sabors_chef]
            sabs_filtrats = [s for s in sabs_norm if s in sabors_chef_norm]

            # Si no aporta cap sabor del xef, no imprimim sabors
            if sabs_filtrats:
                print(f"  - {t} → sabors: {', '.join(sabs_filtrats)}")
            else:
                print(f"  - {t} → sabors: ")
    else:
        print("  (cap)")

    print("\nSubstitucions:")
    for orig, nou in substitucions:
        print(f"  - {orig} → {nou}")
    print()

    print(f"{BOLD}SABORS{RESET}")

    sabors_abans = sabors_actuals
    print(f"Plat original: {', '.join(sabors_abans)}")

    sabors_del_chef = sabors_chef
    print(f"Característics del xef: {', '.join(sabors_del_chef)}")

    sabors_afegits = []
    
    # Sabors afegits per ingredients afegits
    for ing in afegits_per_sabor:
        ing_norm = normalitza_camelcase(ing)
        matching = ingredients[ingredients['Nom-ingredient'] == ing_norm]
        if matching.empty:
            continue
        fila = matching.iloc[0]
        sabors_afegits += parse_llista(fila['Sabor'])

    # Sabors aportats per les tècniques afegides
    sabors_tecniques = []
    for t in tecniques_afegides:
        if t in mapa_sabor_per_tec:
            sabs = mapa_sabor_per_tec[t]
            sabs_norm = [normalitza_camelcase(s) for s in sabs]
            sabors_tecniques.extend(sabs_norm)

    # Combinar: sabors originals + sabors d’ingredients + sabors de tècniques
    sabors_despres = list(dict.fromkeys(
        sabors_actuals + sabors_afegits + sabors_tecniques
    ))

    print(f"Plat adaptat: {', '.join(sabors_despres)}\n")

    print(f"{BOLD}INGREDIENTS{RESET}")
    print("Plat original:")
    print("  " + ", ".join(sorted(ing_actuals)))

    print("\nAfegits (per reforçar sabors):")
    if detalls_per_sabor:
        for ing, sabs in detalls_per_sabor:
            print(f"  - {ing} → sabors: {', '.join(sabs)}")
    else:
        print("  (cap)")

    return plat_nou, nou_menu

def adaptar_estil_plat_MULTIPLE(cas_adults, cas_infantil, preferencies):
    """
    Aplica l’adaptació d’estil de xef a múltiples plats d’un mateix menú.

    Permet adaptar successivament diversos plats del menú, mantenint
    l’estat del menú actualitzat. Quan no es vol adaptar cap plat més,
    el menú final es valida, es demana feedback i es guarda al sistema.
    """

    menu_actual = None

    while True:
        # --------------------------------------------------
        # 1) ADAPTAR UN PLAT (treballant sobre menu_actual)
        # --------------------------------------------------
        plat_nou, menu_nou = adaptar_estil_plat_CASE(
            cas_adults,
            cas_infantil,
            menu_actual=menu_actual,
            preferencies=preferencies
        )

        # Cancel·lació o error
        if menu_nou is None:
            return "__BACK_TO_ADAPTATIONS__"

        # Actualitzem el menú de treball
        menu_actual = menu_nou

        # --------------------------------------------------
        # 2) MOSTRAR ESTAT ACTUAL DEL MENÚ
        # --------------------------------------------------
        print("\n===== MENÚ ACTUAL DESPRÉS DE L'ADAPTACIÓ =====")
        for tipus in ["entrants", "principal", "segon", "postre"]:
            p = menu_actual.plats[tipus]
            if tipus == "entrants":
                print("Entrants:")
                for e in p:
                    print(f"  - {e['Nom-plat']}")
            else:
                print(f"{tipus.capitalize()}: {p['Nom-plat']}")
        print("================================================\n")

        # --------------------------------------------------
        # 3) VOL ADAPTAR UN ALTRE PLAT DEL MATEIX MENÚ?
        # --------------------------------------------------
        while True:
            r = input(
                "Vols adaptar un altre plat d’aquest mateix menú a l'estil d'algun xef? (Si/No)\n  >> "
            ).strip()
            r_norm = normalize_text(r)

            if is_yes(r_norm):
                continuar_mateix_menu = True
                break
            if is_no(r_norm):
                continuar_mateix_menu = False
                break

            print("Si us plau, respon només Si o No.")

        if continuar_mateix_menu:
            continue   # tornem al while i adaptem un altre plat

        # ==================================================
        # 4) AQUÍ S’ACABA EL MENÚ → VALIDAR + FEEDBACK + RETAIN
        # ==================================================
        print("\nValidant el menú adaptat...")
        ok = revisar_cas(menu_actual, preferencies, [])[1]

        if ok:
            print("✓ El menú adaptat és coherent!")
        else:
            print("⚠ El menú adaptat NO és coherent.")

        from utils.feedback import demanar_feedback
        feedback = demanar_feedback()
        menu_actual.feedback = feedback

        retain_cas(menu_actual)
        print("✓ Cas guardat amb feedback.")

        # --------------------------------------------------
        # 5) FLUX SEGONS FEEDBACK
        # --------------------------------------------------
        if feedback["status"] == "SUCCESS":
            print("\nEl menú ha estat ben valorat.")
        else:
            print("\nEl menú s'ha marcat com a FRACÀS.")

        # --------------------------------------------------
        # 6) VOL ADAPTAR UN ALTRE MENÚ?
        # --------------------------------------------------
        while True:
            r2 = input("Vols adaptar un altre menú recomanat? (Si/No)\n  >> ").strip()
            r2_norm = normalize_text(r2)

            if is_yes(r2_norm):
                return "__SELECT_ANOTHER_MENU__"

            if is_no(r2_norm):
                return "__FINISHED_SUCCESS__"

            print("Si us plau, respon només Si o No.")