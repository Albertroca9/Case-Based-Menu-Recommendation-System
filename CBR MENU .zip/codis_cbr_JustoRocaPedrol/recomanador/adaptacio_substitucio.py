# recomanador/adaptacio_substitucio.py

"""
Mòdul de substitució de plats dins del sistema RicoRico.

Permet reemplaçar plats d’un menú per alternatives provinents
de menús similars, tenint en compte les preferències de l’usuari
i evitant duplicats o ingredients prohibits.

Les substitucions formen part del procés d’adaptació interactiva
i s’integren dins del flux de validació, feedback i persistència
del sistema CBR.
"""

# Imports
import re
from cbr.retain import retain_cas
from cbr.revise import revisar_cas
from data.carrega_dades import dicc_plat_ingredients, plats as df_plats
from cbr.retrieve import retrieve_best

def ja_existeix(alternatives, plat):
    """
    Comprova si un plat ja existeix dins d’una llista d’alternatives.

    Serveix per evitar duplicats quan es construeix la llista
    de plats candidats a substituir.
    """

    nom = plat["Nom-plat"].strip().lower()
    return any(
        a["Nom-plat"].strip().lower() == nom
        for a in alternatives
    )

def substituir_plat_CASE(cas, preferencies, infantil=False):
    """
    Permet substituir un o més plats d’un menú per alternatives similars.

    Recupera plats de menús similars, filtra alternatives segons
    preferències (ingredients prohibits) i aplica la substitució
    de manera interactiva.

    En finalitzar el menú:
      - valida la coherència del cas
      - demana feedback
      - guarda el cas adaptat a la base de casos
    """

    print("\n==================== SUBSTITUIR UN PLAT ====================\n")

    menu_actual = cas

    while True:
        # Recuperar menús similars
        _, sims = retrieve_best(preferencies, infantil=infantil)
        plats_orig = menu_actual.plats

        # Llistar plats del menú actual
        llista = []

        if plats_orig["entrants"]:
            for e in plats_orig["entrants"]:
                llista.append(("Entrant", e))

        llista.append(("Principal", plats_orig["principal"]))
        llista.append(("Segon", plats_orig["segon"]))
        llista.append(("Postre", plats_orig["postre"]))

        print("Plats disponibles:")
        for i, (tipus, plat) in enumerate(llista, start=1):
            print(f"{i}. {tipus}: {plat['Nom-plat']}")

        # Selecció plat a substituir
        while True:
            op = input("\nQuin plat vols substituir? (número)\n  >> ").strip()
            if op.isdigit() and 1 <= int(op) <= len(llista):
                idx = int(op) - 1
                tipus_sel, plat_sel = llista[idx]
                break
            print("Opció no vàlida.")

        print(f"\nHas triat: {plat_sel['Nom-plat']} ({tipus_sel})")

        # Buscar alternatives
        alternatives = []

        def mateix_plat(p1, p2):
            return (
                p1 and p2 and
                p1["Nom-plat"].strip().lower() == p2["Nom-plat"].strip().lower()
            )

        for alt_cas, _ in sims:
            if alt_cas.menu_id == menu_actual.menu_id:
                continue

            plats_alt = alt_cas.plats
            candidata = None

            if tipus_sel == "Entrant" and plats_alt["entrants"]:
                for e in plats_alt["entrants"]:
                    if not mateix_plat(e, plat_sel):
                        candidata = e
                        break

            elif tipus_sel == "Principal":
                p = plats_alt["principal"]
                if not mateix_plat(p, plat_sel):
                    candidata = p

            elif tipus_sel == "Segon":
                s = plats_alt["segon"]
                if not mateix_plat(s, plat_sel):
                    candidata = s

            elif tipus_sel == "Postre":
                po = plats_alt["postre"]
                if not mateix_plat(po, plat_sel):
                    candidata = po

            if candidata:
                if preferencies and "ingredients_prohibits" in preferencies:
                    ing_candidats = dicc_plat_ingredients.get(candidata["Nom-plat"], set())
                    if any(ing in preferencies["ingredients_prohibits"] for ing in ing_candidats):
                        continue

                if not ja_existeix(alternatives, candidata):
                    alternatives.append(candidata)

            if len(alternatives) == 3:
                break

        if not alternatives:
            print("No hi ha alternatives disponibles.")
            continue

        # Triar alternatives
        print("\nAlternatives disponibles:")
        for i, alt in enumerate(alternatives, 1):
            print(f"{i}. {alt['Nom-plat']}")

        while True:
            op_alt = input("\nQuina alternativa vols triar? (número)\n  >> ").strip()
            if op_alt.isdigit() and 1 <= int(op_alt) <= len(alternatives):
                nou_plat = alternatives[int(op_alt) - 1].copy()
                break
            print("Opció incorrecta.")

        nou_plat["Nom-plat"] += " (substitut)"

        # Aplicar substitució
        if tipus_sel == "Entrant":
            pos = plats_orig["entrants"].index(plat_sel)
            plats_orig["entrants"][pos] = nou_plat
        else:
            plats_orig[tipus_sel.lower()] = nou_plat

        print("\nSubstitució feta!")

        # Mostrar menú actual
        print("\n===== MENÚ ACTUAL DESPRÉS DE LA SUBSTITUCIÓ =====")
        for tipus in ["entrants", "principal", "segon", "postre"]:
            p = plats_orig[tipus]
            if tipus == "entrants":
                print("Entrants:")
                for e in p:
                    print(f"  - {e['Nom-plat']}")
            else:
                print(f"{tipus.capitalize()}: {p['Nom-plat']}")
        print("====================================================\n")

        # Continuar mateix menú?
        while True:
            r = input("Vols substituir un altre plat d’aquest mateix menú? (Si/No)\n  >> ").strip().lower()
            if r.startswith("s"):
                continuar = True
                break
            if r.startswith("n"):
                continuar = False
                break
            print("Si us plau, respon només Si o No.")

        if continuar:
            continue

        # Final de menú → Validar + Feedback + Retain
        print("\nValidant el menú adaptat...")
        ok = revisar_cas(menu_actual, preferencies or {}, [])[1]
        print("✓ El menú adaptat és coherent!" if ok else "⚠ El menú adaptat NO és coherent!")

        from utils.feedback import demanar_feedback
        feedback = demanar_feedback()
        menu_actual.feedback = feedback

        retain_cas(menu_actual)
        print("✓ Cas guardat amb feedback.")

        # Altre menú?
        while True:
            r2 = input("Vols adaptar un altre menú recomanat? (Si/No)\n  >> ").strip().lower()

            if r2.startswith("s"):
                return "__SELECT_ANOTHER_MENU__"

            if r2.startswith("n"):
                return "__FINISHED_SUCCESS__"

            print("Si us plau, respon només Si o No.")

def imprimir_resum_case(cas, preferencies, infantil=False):
    """
    Mostra un resum textual del menú actual.

    Imprimeix els plats del menú (entrants, principal, segon i postre),
    diferenciant entre menú d’adults o infantil, per facilitar
    la revisió final per part de l’usuari.
    """

    print("="*60)
    print("                 RESUM DEL MENÚ")
    print("="*60)

    if not infantil:
        print(f"\nMENÚ ADULTS ({cas.menu_id}):")
    else:
        print(f"\nMENÚ INFANTIL ({cas.menu_id}):")

    plats = cas.plats

    # Entrants.
    if plats["entrants"]:
        print("  • Entrants:")
        for e in plats["entrants"]:
            print(f"      - {e['Nom-plat']}")
    else:
        print("  • Entrants: (No hi ha entrants)")

    # Principal, segon i postre.
    print(f"  • Principal: {plats['principal']['Nom-plat']}")
    print(f"  • Segon:     {plats['segon']['Nom-plat']}")
    print(f"  • Postre:    {plats['postre']['Nom-plat']}")

    print("\n" + "="*60 + "\n")
