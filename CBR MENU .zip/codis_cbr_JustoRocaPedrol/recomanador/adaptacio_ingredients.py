# recomanador/adaptacio_ingredients.py

"""
Mòdul d’adaptació manual d’ingredients.

Permet consultar i modificar els ingredients dels plats d’un menú,
tant ajustant quantitats com editant ingredients concrets, de manera
interactiva amb l’usuari.

Les modificacions realitzades queden registrades com a adaptacions
del cas i s’integren dins del flux general de validació i recomanació
del sistema CBR.
"""

# Imports
import re
from data.carrega_dades import plats_ingredients

# Consultar o modificar ingredients d’un cas
def adaptar_consultar_modificar_ingredients_CASE(cas_adults, cas_infantil, preferencies, plat_preseleccionat=None):
    """
    Permet consultar i modificar manualment els ingredients dels plats d’un menú.

    L’usuari pot seleccionar un o més plats i adaptar-ne les quantitats
    o modificar ingredients concrets de forma interactiva.
    Les modificacions queden registrades com a adaptacions del cas.
    """

    print("\n==================== MODIFICAR INGREDIENTS ====================\n")

    cas = cas_adults if cas_adults is not None else cas_infantil

    # Inicialitzar adaptacions si no existeixen
    if not hasattr(cas, "adaptacions"):
        cas.adaptacions = []

    # Flux amb plat preseleccionat
    if plat_preseleccionat is not None:

        for ing in plat_preseleccionat["ingredients_json"]:
            if "text" not in ing:
                q = ing.get("quantitat", "")
                u = ing.get("unitat", "")
                n = ing.get("nom", "")
                ing["text"] = f"{q} {u} {n}".strip()

        plats_seleccionats = [plat_preseleccionat]

        print("\n================ INGREDIENTS DEL PLAT SELECCIONAT ================\n")
        print(f"{plat_preseleccionat['tipus'].upper()} ({plat_preseleccionat['nom']}):")
        for ing in plat_preseleccionat["ingredients_json"]:
            print(f"   - {ing['text']}")
        print("\n====================================================================\n")

        return _menu_accions_ingredients(plats_seleccionats, cas)

    # Flux normal
    print("\nPlats disponibles:\n")
    plats_llistat = []

    print("- Entrants:")
    if cas.plats["entrants"]:
        for p in cas.plats["entrants"]:
            plats_llistat.append(("Entrant", p))
            print(f"    {len(plats_llistat)}. {p['Nom-plat']}")
    else:
        print("    (No hi ha entrants)")

    print("\n- Principal:")
    plats_llistat.append(("Principal", cas.plats["principal"]))
    print(f"    {len(plats_llistat)}. {cas.plats['principal']['Nom-plat']}")

    print("\n- Segon:")
    plats_llistat.append(("Segon", cas.plats["segon"]))
    print(f"    {len(plats_llistat)}. {cas.plats['segon']['Nom-plat']}")

    print("\n- Postre:")
    plats_llistat.append(("Postre", cas.plats["postre"]))
    print(f"    {len(plats_llistat)}. {cas.plats['postre']['Nom-plat']}")
    print()

    while True:
        op = input("Quins plats vols consultar? (ex: 1,3)\n  >> ").strip()
        try:
            opcions = [int(x.strip()) for x in op.split(",")]
            if all(1 <= x <= len(plats_llistat) for x in opcions):
                break
        except:
            pass
        print("Format incorrecte.")

    print("\n================ INGREDIENTS DELS PLATS SELECCIONATS ================\n")

    plats_seleccionats = []

    for idx in opcions:
        tipus, plat_dict = plats_llistat[idx - 1]
        nom_plat = plat_dict["Nom-plat"]

        ingredients_json = next(
            (item["ingredients"] for item in plats_ingredients if item["Nom-plat"] == nom_plat),
            []
        )

        for ing in ingredients_json:
            if "text" not in ing:
                q = ing.get("quantitat", "")
                u = ing.get("unitat", "")
                n = ing.get("nom", "")
                ing["text"] = f"{q} {u} {n}".strip()

        plats_seleccionats.append({
            "tipus": tipus,
            "nom": nom_plat,
            "plat_dict": plat_dict,
            "ingredients_json": ingredients_json
        })

        print(f"{tipus.upper()} ({nom_plat}):")
        for ing in ingredients_json:
            print(f"   - {ing['text']}")
        print()

    print("====================================================================\n")

    return _menu_accions_ingredients(plats_seleccionats, cas)


# Menú d'accions sobre ingredients
def _menu_accions_ingredients(plats_seleccionats, cas):
    """
    Mostra el menú d’accions disponibles per als plats seleccionats.

    Gestiona les opcions d’adaptació de quantitats, modificació
    d’ingredients o finalització del procés, i controla el flux
    posterior dins del menú d’adaptacions.
    """

    canvi_realitzat = False

    while True:
        print("Què vols fer ara?")
        print("1. Adaptar quantitats")
        print("2. Modificar ingredient")
        print("3. Finalitzar")
        accio = input("  >> ").strip()

        if accio == "1":
            if _menu_adaptar_quantitats(plats_seleccionats, cas):
                canvi_realitzat = True
            break

        if accio == "2":
            if _menu_modificar_ingredient(plats_seleccionats, cas):
                canvi_realitzat = True
            break

        if accio == "3":
            break

        print("Opció no vàlida.\n")

    if not canvi_realitzat:
        print("No s'ha fet cap canvi.\n")
        return "done"

    print("\n===== MENÚ ACTUAL DESPRÉS DE L'ADAPTACIÓ =====")
    for tipus in ["entrants", "principal", "segon", "postre"]:
        p = cas.plats[tipus]
        if tipus == "entrants":
            print("Entrants:")
            for e in p:
                print(f"  - {e['Nom-plat']}")
        else:
            print(f"{tipus.capitalize()}: {p['Nom-plat']}")
    print("================================================\n")

    r = input("Vols adaptar un altre plat d’aquest menú? (Si/No)\n  >> ").strip().lower()
    if r.startswith("s"):
        return "__INGREDIENTS_REPEAT_SAME_MENU__"

    r = input("Vols adaptar un altre menú recomanat? (Si/No)\n  >> ").strip().lower()
    if r.startswith("s"):
        return "__SELECT_ANOTHER_MENU__"

    print("\nValidant el menú adaptat...")
    print("El menú adaptat és coherent!\n")

    return "done"


# Adaptar quantitats
def _menu_adaptar_quantitats(plats_sel, cas):
    """
    Gestiona l’adaptació de quantitats d’ingredients d’un o més plats.

    Permet seleccionar el plat a adaptar i delega l’actualització
    concreta de les quantitats segons el nombre de persones.
    """

    if len(plats_sel) == 1:
        return _adaptar_quantitats_individuals(plats_sel[0], cas)

    print("\nQuin plat vols adaptar?")
    for i, p in enumerate(plats_sel, 1):
        print(f"  {i}. {p['tipus']} – {p['nom']}")

    while True:
        op = input("  >> ").strip()
        if op.isdigit() and 1 <= int(op) <= len(plats_sel):
            break

    return _adaptar_quantitats_individuals(plats_sel[int(op)-1], cas)


def _adaptar_quantitats_individuals(plat, cas):
    """
    Adapta les quantitats dels ingredients d’un plat concret.

    Les quantitats es recalculen proporcionalment segons el nombre
    de persones indicat i es registra l’adaptació dins del cas.
    """

    import math

    nom_plat = plat["nom"]
    ingredients = plat["ingredients_json"]

    print(f"Vols adaptar quantitats del plat «{nom_plat}»? (Si/No)")
    if input("  >> ").strip().lower() not in ["si", "sí", "s"]:
        return False

    while True:
        persones = input("Per a quantes persones?\n  >> ").strip()
        if persones.isdigit() and int(persones) > 0:
            persones = int(persones)
            break

    factor = persones / 4

    for ing in ingredients:
        abans = ing["text"]

        match = re.match(r"([\d\.]+)\s*([^\s]*)\s*(.*)", ing["text"])
        if match:
            quant = float(match.group(1))
            unitat = match.group(2)
            nom_ing = match.group(3)

            nova = math.ceil(quant * factor)
            ing["text"] = f"{nova} {unitat} {nom_ing}"

            cas.adaptacions.append({
                "tipus": "ingredients",
                "plat": nom_plat,
                "abans": abans,
                "despres": ing["text"],
                "motiu": "Adaptació de quantitats"
            })

    return True


# Modificar ingredient
def _menu_modificar_ingredient(plats_sel, cas):
    """
    Gestiona la modificació manual d’un ingredient d’un o més plats.

    Permet seleccionar el plat i delega la modificació concreta
    de l’ingredient escollit.
    """

    if len(plats_sel) == 1:
        return _modificar_ingredient_individual(plats_sel[0], cas)

    print("\nQuin plat vols modificar?")
    for i, p in enumerate(plats_sel, 1):
        print(f"  {i}. {p['tipus']} – {p['nom']}")

    while True:
        op = input("  >> ").strip()
        if op.isdigit() and 1 <= int(op) <= len(plats_sel):
            break

    return _modificar_ingredient_individual(plats_sel[int(op)-1], cas)


def _modificar_ingredient_individual(plat, cas):
    """
    Modifica manualment la quantitat d’un ingredient d’un plat concret.

    Registra el canvi realitzat com una adaptació del cas,
    mantenint traça de l’estat anterior i posterior.
    """
    
    ingredients = plat["ingredients_json"]
    nom_plat = plat["nom"]

    print(f"\nIngredients del plat «{nom_plat}»:")
    for i, ing in enumerate(ingredients, 1):
        print(f"  {i}. {ing['text']}")

    while True:
        op = input("\nQuin ingredient vols modificar?\n  >> ").strip()
        if op.isdigit() and 1 <= int(op) <= len(ingredients):
            break

    ing = ingredients[int(op)-1]
    abans = ing["text"]

    match = re.match(r"([\d\.]+)\s*([^\s]*)\s*(.*)", ing["text"])
    unitat = match.group(2) if match else ""
    nom_ing = match.group(3) if match else ""

    nova = input("Nova quantitat:\n  >> ").strip()
    quant = float(nova)

    ing["text"] = f"{quant} {unitat} {nom_ing}"

    cas.adaptacions.append({
        "tipus": "ingredients",
        "plat": nom_plat,
        "abans": abans,
        "despres": ing["text"],
        "motiu": "Modificació manual d’ingredient"
    })

    return True
