# recomanador/llm_explicacio.py

"""
Mòdul d'explicació del menú mitjançant LLM.

Aquest mòdul NO participa en la presa de decisions.
Només genera una explicació textual del perquè
un menú és adequat segons les preferències de l'usuari.

Es pot usar:
 - amb un LLM real (API)
 - o amb una explicació heurística (fallback)
"""

# Imports
import os
from dotenv import load_dotenv
from openai import OpenAI
import os

# OPCIÓ 1 — EXPLICACIÓ HEURÍSTICA (SENSE LLM REAL)
load_dotenv(override=True)

key = os.getenv("OPENAI_API_KEY")


def _explicacio_fallback(dades):
    """
    Genera una explicació automàtica sense LLM.
    Útil si no hi ha API o per demostració acadèmica.
    """

    pref = dades.get("preferencies", {})
    plats = dades.get("menu_final", {})

    txt = []
    txt.append(f"El menú seleccionat ({dades.get('menu_id')}) ha estat recomanat ")
    txt.append("perquè s’ajusta de manera coherent a les preferències indicades.\n")

    # Context
    if pref.get("esdeveniment"):
        txt.append(f"- Tipus d’esdeveniment: {pref['esdeveniment']}\n")
    if pref.get("temporada"):
        txt.append(f"- Temporada: {pref['temporada']}\n")
    if pref.get("estil"):
        txt.append(f"- Estil gastronòmic: {pref['estil']}\n")
    if pref.get("complexitat_adults"):
        txt.append(f"- Nivell de complexitat: {pref['complexitat_adults']}\n")

    txt.append("\nEl menú inclou una combinació equilibrada de plats:\n")

    if plats.get("entrants"):
        for p in plats["entrants"]:
            txt.append(f"  • Entrant: {p}\n")
    if plats.get("principal"):
        txt.append(f"  • Plat principal: {plats['principal']}\n")
    if plats.get("segon"):
        txt.append(f"  • Segon plat: {plats['segon']}\n")
    if plats.get("postre"):
        txt.append(f"  • Postre: {plats['postre']}\n")

    txt.append(
        "\nEn conjunt, el menú manté una coherència entre estil, "
        "temporada i complexitat, oferint una proposta adequada "
        "pel context indicat."
    )

    return "".join(txt)


# OPCIÓ 2 — EXPLICACIÓ AMB LLM REAL (OPCIONAL)
def _get_client():
    """
    Crea el client OpenAI només quan cal.
    Això evita errors en importació.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY no definida com a variable d'entorn."
        )
    return OpenAI(api_key=api_key)


def _explicacio_llm_real(dades):
    """
    Genera una explicació amb OpenAI a partir del menú i preferències.
    """

    prompt = f"""
Ets un expert en gastronomia i sistemes de recomanació de menús.

La teva tasca és explicar detalladament per què el menú proposat
és una bona elecció per a l'usuari, basant-te en les seves preferències
i en les característiques dels plats seleccionats.

Preferències de l'usuari:
{dades.get("preferencies")}

Menú recomanat:

{dades.get("menu_final")}
Adaptacions realitzades:
{dades.get("adaptacions")}
Context del menú:
- Temporada: {dades.get("temporada")}
- Estil gastronòmic: {dades.get("estil")}
- Nivell de complexitat: {dades.get("complexitat")}

Redacta una explicació:
- Clara i ben estructurada
- Amb un petit paràgraf introductori
- Justificant la coherència del menú amb l'estil i la temporada
- Explicant l'equilibri entre els diferents plats (entrants, principal, segon i postres)
- Amb un to professional però entenedor per a un usuari no expert
- Quan parlis dels plats fes-ho en modo llista: Els plats que es vegin de manera clara i la explicació a sota així queda tot clar.
No llistis dades en brut; integra-les de manera natural en el text.
- IMPORTANTÍSSIM: Si s'han realitzat adaptacions o canvis de quantitats, ingredients, cultura o chef vull que justifiquis per què s'ha fet i com això millora el menú o el canvia (sempre cap a bé)
"""


    client = _get_client()

    response = client.chat.completions.create(
    
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "Ets un expert en gastronomia i recomanació de menús."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        max_tokens=1000
    )

    return response.choices[0].message.content.strip()

# Funció pública d'explicació
def generar_explicacio_llm(dades, usar_llm_real=False,):
    """
    Genera una explicació textual del menú recomanat.

    La funció decideix si utilitzar un model LLM real o una explicació
    alternativa (fallback) en funció del paràmetre `usar_llm_real`.
    En cas d’error durant la generació amb LLM, es recupera
    automàticament l’explicació de fallback per garantir una resposta.
    """
    
    if usar_llm_real:
        try:
            return _explicacio_llm_real(dades)
        except Exception as e:
            print("[DEBUG] ERROR dins LLM:", repr(e))
            return _explicacio_fallback(dades)

    return _explicacio_fallback(dades)
