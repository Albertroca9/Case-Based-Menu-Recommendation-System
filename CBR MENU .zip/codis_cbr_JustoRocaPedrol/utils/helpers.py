# utils/helpers.py

"""
Funcions auxiliars del sistema RicoRico.

Inclou utilitats de normalització de text, gestió d’entrada
d’usuari (ask), detecció d’exit/reset, autocorrecció d’opcions
i formatació d’ingredients i noms en CamelCase.
"""

# Imports
import sys
import time
import re
import unicodedata
from difflib import get_close_matches
import pandas as pd

# Colors
BOLD = "\033[1m"
RED = "\033[91m"
RESET = "\033[0m"

# FUNCIONS DE NORMALITZACIÓ
def treu_accents(text):
    """
    Elimina els accents d’un text Unicode.
    """

    return "".join(
        c for c in unicodedata.normalize("NFD", text)
        if unicodedata.category(c) != "Mn"
    )

def normalitza_camelcase(text):
    """
    Normalitza un text a format CamelCase.

    Manté el CamelCase existent si ja és vàlid
    i transforma entrades d’usuari lliures a CamelCase.
    """

    if not isinstance(text, str):
        text = str(text)

    # Neteja bàsica
    text = treu_accents(text)
    text = re.sub(r"[\'’`]", "", text)
    text = text.replace("·", "")

    # Si ja és CamelCase (filetIberic, FiletIberic, etc.)
    # i no conté espais ni guions → NO TOCAR
    if re.match(r'^[A-Za-z]+$', text) and any(c.isupper() for c in text[1:]):
        return text  # mantenir CamelCase original

    # En altres casos (text d'usuari), separar per espais
    paraules = re.split(r"\s+", text.strip())
    paraules = [p.capitalize() for p in paraules if p.strip()]
    return "".join(paraules)

def normalitza_sabors_col(df, colname):
    """
    Normalitza una columna de sabors d’un DataFrame a CamelCase.

    Cada sabor queda separat per comes.
    """

    def norm_row(val):
        """
        Normalitza una fila de valors separats per comes a CamelCase.
        """

        if pd.isna(val):
            return ""
        parts = [p.strip() for p in str(val).split(",")]
        parts_norm = [normalitza_camelcase(p) for p in parts if p.strip()]
        return ", ".join(parts_norm)

    df[colname] = df[colname].apply(norm_row)
    return df

def normalitza_tecnica_col(df, colname):
    """
    Normalitza una columna de tècniques culinàries a CamelCase.
    """

    def norm_row(val):
        """
        Normalitza una fila de valors separats per comes a CamelCase.
        """

        if pd.isna(val):
            return ""
        parts = [p.strip() for p in str(val).split(",")]
        parts_norm = [normalitza_camelcase(p) for p in parts if p.strip()]
        return ", ".join(parts_norm)

    df[colname] = df[colname].apply(norm_row)
    return df

def normalitza_ingredients_4p(text):
    """
    Normalitza el text d’ingredients per a 4 persones.

    Converteix els noms a CamelCase mantenint quantitat i unitat.
    """

    if not isinstance(text, str) or text.strip() == "":
        return text

    parts = re.split(r"[,;]+", text)
    result = []

    for p in parts:
        trobat = p.strip()

        # Intenta capturar quantitat + unitat + nom
        m = re.match(r"(\d+(?:\.\d+)?)\s*([a-zA-Z]+)\s+(.+)", trobat)
        if m:
            quant = m.group(1)
            unit = m.group(2)
            nom = m.group(3)

            nom_norm = normalitza_camelcase(nom.strip())
            result.append(f"{quant} {unit} {nom_norm}")

        else:
            # Nom sol
            nom_norm = normalitza_camelcase(trobat)
            result.append(nom_norm)

    return ", ".join(result)

# Conjunts de paraules clau
EXIT_WORDS = {"exit", "quit", "sortir", "surt", "q", "exit()"}
RESET_WORDS = {"reset", "reinicia", "restart"}

YES_WORDS = {"si", "s", "yes", "y"}
NO_WORDS = {"no", "n", "not"}

# Funcions de normalització de text
def normalize_text(s):
    """
    Normalitza un text per comparacions:
    minúscules i sense accents.
    """

    s = s.strip().lower()
    s = ''.join(c for c in unicodedata.normalize('NFD', s)
                if unicodedata.category(c) != 'Mn')
    return s

def is_yes(ans):
    """
    Retorna True si la resposta és afirmativa.
    """

    return normalize_text(ans) in YES_WORDS

def is_no(ans):
    """
    Retorna True si la resposta és negativa.
    """

    return normalize_text(ans) in NO_WORDS

def user_wants_exit(text):
    """
    Detecta si l’usuari vol sortir del programa.
    """

    return normalize_text(text) in EXIT_WORDS

def user_wants_reset(text):
    """
    Detecta si l’usuari vol reiniciar el sistema.
    """

    return normalize_text(text) in RESET_WORDS

# Funcions de gestió exit/reset
def check_exit(raw_input):
    """
    Comprova si l’entrada indica sortir del programa
    i gestiona la confirmació corresponent.
    """

    if user_wants_exit(raw_input):
        ask_exit_confirmation()
        return True
    return False

def check_reset(raw_input):
    """
    Comprova si l’entrada indica un reinici total del sistema.
    """

    if user_wants_reset(raw_input):
        if ask_restart_confirmation():
            return True  
    return False

def ask_exit_confirmation():
    """
    Demana confirmació explícita abans de sortir del programa.
    """

    while True:
        resp = input("Segur que vols sortir? (Si/No)\n  >> ").strip()
        if check_exit(resp) or check_reset(resp):
            continue
        if is_yes(resp):
            print("Sortint.")
            sys.exit(0)
        elif is_no(resp):
            return
        print("Respon Si o No.")

def ask_restart_confirmation():
    """
    Demana confirmació abans de reiniciar completament el recomanador.
    """

    while True:
        print("Vols reiniciar TOT el recomanador des del principi? (Si/No)")
        time.sleep(0.1)
        resp = input("  >> ").strip()
        if check_exit(resp) or check_reset(resp):
            continue

        if is_yes(resp):
            print("Reiniciant tot el recomanador...\n")
            time.sleep(0.1)
            return True

        if is_no(resp):
            return False

        print("Respon Si o No.")

# Funció d'autocorrecció
def corrected_option(user_input, valid_options):
    """
    Retorna l’opció més similar a l’entrada de l’usuari,
    si la coincidència és prou alta.
    """

    norm_input = normalize_text(user_input)
    norm_options = [normalize_text(o) for o in valid_options]
    match = get_close_matches(norm_input, norm_options, n=1, cutoff=0.70)
    if match:
        idx = norm_options.index(match[0])
        return valid_options[idx]
    return None

# Funció central d'entrada robusta
def ask(text, cast=str, options=None):
    """
    Funció central d’entrada robusta.

    Gestiona:
      - exit / reset globals
      - autocorrecció d’opcions
      - validació de tipus
      - reinici total amb "__RESTART_ALL__"
    """

    while True:

        print(text)
        time.sleep(0.1)

        ans = input("  >> ").strip()

        # Sortida
        if user_wants_exit(ans):
            ask_exit_confirmation()
            continue

        # Reset
        if user_wants_reset(ans):
            if ask_restart_confirmation():
                return "__RESTART_ALL__"
            else:
                continue

        # Cadena buida
        if ans == "":
            print("Cal introduir un valor.")
            continue

        norm = normalize_text(ans)

        # Opcions predefinides
        if options:
            norm_options = [normalize_text(o) for o in options]

            # Acceptació directa (coincidència exacta)
            if norm in norm_options:
                return options[norm_options.index(norm)]

            # Suggeriment de coincidència aproximada
            sugg = corrected_option(ans, options)
            if sugg:
                print(f"Volies dir «{sugg}»?")
                time.sleep(0.1)

                conf = input("  >> ").strip()

                # Validar exit/reset també al confirmar
                if user_wants_exit(conf):
                    ask_exit_confirmation()
                    continue

                if user_wants_reset(conf):
                    if ask_restart_confirmation():
                        return "__RESTART_ALL__"
                    else:
                        continue

                if is_yes(conf):
                    return sugg
                else:
                    print("Torna-ho a escriure.")
                    continue

            print(f"Opció no vàlida. Opcions: {', '.join(options)}")
            continue

        # Enter
        if cast == int:
            try:
                return int(ans)
            except ValueError:
                print("Has d'introduir un número enter.")
                continue

        # Text lliure
        return ans

def neteja_ingredient_usuari(text):
    """
    Neteja un ingredient introduït per l’usuari.

    Elimina accents, símbols estranys i espais sobrants.
    """

    if not isinstance(text, str):
        text = str(text)

    # Neteja d'accents
    text = ''.join(
        c for c in unicodedata.normalize("NFD", text)
        if unicodedata.category(c) != "Mn"
    )

    # Eliminar símbols sobrers
    text = re.sub(r"[^\w\s]", " ", text)  # elimina símbols no alfabètics
    text = re.sub(r"\s+", " ", text).strip()

    return text

def camel_to_text(name):
    """
    Converteix un nom en CamelCase a text llegible.
    """

    import re
    if not isinstance(name, str):
        return str(name)

    # Afegir espai abans de majúscules interiors
    s = re.sub(r'(?<!^)(?=[A-Z])', ' ', name)
    # Posar primera lletra en majúscules
    return s.strip().capitalize()

def format_variant_with_quantity(original_text, nova_variant):
    """
    Substitueix el nom d’un ingredient mantenint
    quantitat i unitat originals.
    """

    # Parsejar l'ingredient original
    m = re.match(r"([\d\.]+)\s*([a-zA-Zà-úÀ-Ú·]+)\s+(.*)", original_text)
    if not m:
        return camel_to_text(nova_variant)

    quant = m.group(1)
    unit = m.group(2)
    # nom original ignorat → el substituïm

    # Convertir camelCase a text humà
    nom_nou = camel_to_text(nova_variant)

    return f"{quant} {unit} {nom_nou}"

