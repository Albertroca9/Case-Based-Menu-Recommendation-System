# utils/feedback.py

"""
Mòdul de gestió de feedback d’usuari.

Permet recollir una valoració numèrica del menú recomanat
i classificar el resultat com a èxit o fracàs, indicant
el motiu quan la puntuació és baixa.
"""

def demanar_feedback():
    """
    Demana feedback a l’usuari sobre el menú.

    Sol·licita una puntuació de l’1 al 10 i retorna
    un diccionari amb la valoració, l’estat (SUCCESS o FAIL)
    i un comentari opcional en cas de fracàs.
    """
    
    while True:
        try:
            rating = int(input("\nValora el menú de l'1 al 10:\n >> "))
            if 1 <= rating <= 10:
                break
        except:
            pass
        print("Introdueix un número entre 1 i 10.")

    feedback = {
        "rating": rating,
        "status": "SUCCESS",
        "comment": None
    }

    if rating <= 5:
        print("\nPer què li dones aquesta puntuació?")
        print("  1. Incompleix alguna al·lèrgia / intolerància")
        print("  2. No m'ha agradat com ha quedat")

        while True:
            r = input(" >> ").strip()
            if r in ("1", "2"):
                break

        if r == "1":
            feedback["status"] = "FAIL_ALLERGY"
        else:
            feedback["status"] = "FAIL_TASTE"

        feedback["comment"] = input(
            "\nPots explicar breument el motiu? (opcional)\n >> "
        )

    return feedback
