# cbr/revise.py

"""
Fase REVISE del CBR.
Valida el cas adaptat i detecta incoherències.
"""

# Imports
from cbr.reuse import plat_case_te_prohibit
from data.carrega_dades import dicc_plat_ingredients

def revisar_cas(cas_adaptat, preferencies, canvis):
    """
    Retorna:
      - cas_adaptat
      - valid (True/False)
    """

    print("\n===================== FASE REVISE =====================")

    # Mostrar canvis aplicats
    if canvis:
        print("Canvis aplicats:")
        for orig, nou in canvis:
            print(f"  • {orig}  →  {nou}")
    else:
        print("No s'ha aplicat cap canvi automàtic.")

    print("\nComprovant coherència...\n")

    errors = []

    # Comprovació de plats nuls / incomplets
    for tipus, plats in cas_adaptat.plats.items():

        # Salt d’entrants en menú infantil
        if cas_adaptat.menu_id.startswith("MenuInf") and tipus == "entrants":
            continue

        # Entrants → és una llista
        if tipus == "entrants":
            if not plats or any(p is None for p in plats):
                errors.append("Falten entrants o algun entrant és nul.")

        # Altres plats → un únic plat
        else:
            if plats is None:
                errors.append(f"No hi ha plat per a: {tipus}")

    # Detecció d’ingredients prohibits
    prohibits = set(preferencies.get("ingredients_prohibits", []))

    if prohibits:

        # Entrants (si NO és infantil)
        if not cas_adaptat.menu_id.startswith("MenuInf"):

            for p in cas_adaptat.plats.get("entrants", []):
                if p and plat_case_te_prohibit(p, prohibits):
                    errors.append(f"L'entrant {p['Nom-plat']} conté ingredients prohibits.")

        # Principal / Segon / Postre
        for key in ["principal", "segon", "postre"]:
            p = cas_adaptat.plats.get(key)
            if p and plat_case_te_prohibit(p, prohibits):
                errors.append(f"El plat {key}: {p['Nom-plat']} conté ingredients prohibits.")

    # Resultat final
    if errors:
        print("⚠ S'han detectat incoherències:")
        for e in errors:
            print("  -", e)
        return cas_adaptat, False

    # print("✓ El menú adaptat és coherent.")
    return cas_adaptat, True