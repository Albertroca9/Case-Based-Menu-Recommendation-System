# cbr/retain.py

"""
Fase RETAIN del CBR.

Aquest mòdul s’encarrega de guardar a la base de dades els menús
adaptats (casos nous), incloent tots els seus plats i el feedback
associat, per tal que puguin ser reutilitzats en futures recomanacions.
"""

# Imports
import os
import pandas as pd
from copy import deepcopy
from casos.case_base import CASE_BASE
from data.carrega_dades import plats as DF_PLATS

CSV_PATH = "data/plats.csv"

COLUMNS = [
    "Nom-plat",
    "Complexitat",
    "Ingredients-4p",
    "Sabor",
    "Tecniques",
    "Origen-plat",
    "Preu-plat",
    "Temperatura",
    "Temporada",
    "Tipus-plat",
    "Tipus-public",
    "Estil-plat",
    "Menu",
    "Feedback_Rating",
    "Feedback_Status",
    "Feedback_Comment"
]


def _ensure_csv():
    """
    Crear CSV si no existeix.
    """
    if not os.path.exists(CSV_PATH):
        df = pd.DataFrame(columns=COLUMNS)
        df.to_csv(CSV_PATH, index=False)


def retain_cas(cas_adaptat, tipus_menu=None):
    """
    Guarda un cas adaptat a la base de dades.

    Assigna un identificador únic al menú (adults o infantil),
    extreu el feedback si existeix i desa tots els plats associats
    al menú dins del CSV persistent de casos adaptats.
    """

    print("\n===================== FASE RETAIN =====================")

    # Assegurar que el CSV de persistència existeix
    _ensure_csv()
    df = pd.read_csv(CSV_PATH)

    # Determina si el menú es Infantil o d'Adults
    # prioritat: paràmetre passat manualment
    if tipus_menu is None:
        # detecció automàtica a partir del cas
        if hasattr(cas_adaptat, "es_infantil") and cas_adaptat.es_infantil:
            tipus_menu = "infantil"
        else:
            tipus_menu = "adults"

    # Prefix segons tipus de menú
    prefix = "MenuInfAdaptat" if tipus_menu == "infantil" else "MenuAdaptat"

    # Generar un nou ID de menú
    # Recuperar IDs existents
    ids_existents = df["Menu"].dropna().astype(str)
    ids_existents = [m for m in ids_existents if m.startswith(prefix)]

    # Extreure la part mumèrica i trobar el següent número
    nums = []
    import re
    for m in ids_existents:
        match = re.search(r"(\d+)$", m)
        if match:
            nums.append(int(match.group(1)))

    # Calcular següent indentificador disponible
    next_num = max(nums) + 1 if nums else 1
    menu_id = f"{prefix}{next_num}"

    # Recuperar feedback associat al cas (si existeix)
    feedback = getattr(cas_adaptat, "feedback", {}) or {}

    fb_rating  = feedback.get("rating", "")
    fb_status  = feedback.get("status", "")
    fb_comment = feedback.get("comment", "")

    print(f"✓ Guardant menú com {menu_id}")

    print("DEBUG feedback al retain:", feedback)

    # Guardar tots els plats
    _guardar_plats(
        df,
        cas_adaptat,
        menu_id,
        fb_rating,
        fb_status,
        fb_comment
    )

    df.to_csv(CSV_PATH, index=False)

    print(f"✔ Menú {menu_id} guardat correctament!\n")
    return True

def _guardar_plats(df, cas, menu_id, fb_rating=None, fb_status=None, fb_comment=None):
    """
    Desa tots els plats d’un menú a la base de dades.

    Recorre els diferents tipus de plats del cas (entrants, principal,
    segon i postre) i els guarda individualment associats al mateix
    identificador de menú i al feedback corresponent.
    """

    # Entrants (llista)
    for p in cas.plats["entrants"]:
        _guardar_un_plat(df, p, cas, "Entrant", menu_id, fb_rating, fb_status, fb_comment)

    # Principal
    if cas.plats["principal"]:
        _guardar_un_plat(df, cas.plats["principal"], cas, "Principal", menu_id, fb_rating, fb_status, fb_comment)
    # Segon
    if cas.plats["segon"]:
        _guardar_un_plat(df, cas.plats["segon"], cas, "Segon", menu_id, fb_rating, fb_status, fb_comment)

    # Postre
    if cas.plats["postre"]:
        _guardar_un_plat(df, cas.plats["postre"], cas, "Postre", menu_id, fb_rating, fb_status, fb_comment)


def _buscar_plat_original(nom_plat_actual):
    """
    Si el nom conté '(estil X)', eliminem aquesta part i retornem el nom original.
    """
    if "(" in nom_plat_actual:
        base = nom_plat_actual.split("(")[0].strip()
        if base in DF_PLATS["Nom-plat"].values:
            return base
    return nom_plat_actual


def _guardar_un_plat(df, plat, cas, tipus, menu_id, fb_rating=None, fb_status=None, fb_comment=None):
    """
    Guarda una fila al CSV.
    - Si el plat és adaptat → guardem dades adaptades (ingredients, tècniques, sabors…).
    - Si no és adaptat → guardem dades del CSV original DF_PLATS.
    """

    nom_adaptat = plat["Nom-plat"]
    # Un plat és adaptat si:
    # - té sufix de xef: (estil X)
    # - té sufix d’al·lèrgia: (sense X)
    # - té altres sufixos personalitzats
    es_adaptat = (
        "(estil" in nom_adaptat.lower()
        or "(sense" in nom_adaptat.lower()
        or "(substitut" in nom_adaptat.lower()
        or "(origen" in nom_adaptat.lower() 
    )

    # Plat adaptat → guardem dades adaptades
    if es_adaptat:

        nova_fila = {
            "Nom-plat": nom_adaptat,
            "Complexitat": cas.complexitat,

            # Dades adaptades
            "Ingredients-4p": plat.get("Ingredients-4p", ""),
            "Sabor": plat.get("Sabor", ""),
            "Tecniques": plat.get("Tecniques", ""),

            # Origen adaptat o original (depèn si l’adaptació l’ha guardat com "Origen" o "Origen-plat")
            "Origen-plat": plat.get("Origen-plat") or plat.get("Origen") or "",

            "Preu-plat": plat.get("Preu-plat", ""),
            "Temperatura": plat.get("Temperatura", ""),
            "Tipus-public": plat.get("Tipus-public", ""),

            # Camps generals del cas
            "Temporada": cas.temporada,
            "Tipus-plat": tipus,
            "Estil-plat": cas.estil,
            "Menu": menu_id,
            "Feedback_Rating": fb_rating,
            "Feedback_Status": fb_status,
            "Feedback_Comment": fb_comment

        }

        df.loc[len(df)] = nova_fila
        return

    # Plat original → recuperar del CSV base
    nom_original = _buscar_plat_original(nom_adaptat)
    fila_orig = DF_PLATS.loc[DF_PLATS["Nom-plat"] == nom_original]

    if fila_orig.empty:
        print(f"⚠ No es troba el plat original: {nom_original}")
        return

    fila_orig = fila_orig.iloc[0]

    nova_fila = {
        "Nom-plat": nom_adaptat,
        "Complexitat": fila_orig.get("Complexitat", cas.complexitat),
        "Ingredients-4p": fila_orig.get("Ingredients-4p", ""),
        "Sabor": fila_orig.get("Sabor", ""),
        "Tecniques": fila_orig.get("Tecniques", ""),
        "Origen-plat": fila_orig.get("Origen-plat", ""),
        "Preu-plat": fila_orig.get("Preu-plat", ""),
        "Temperatura": fila_orig.get("Temperatura", ""),
        "Temporada": cas.temporada,
        "Tipus-plat": tipus,
        "Tipus-public": fila_orig.get("Tipus-public", ""),
        "Estil-plat": cas.estil,
        "Menu": menu_id,
        "Feedback_Rating": fb_rating,
        "Feedback_Status": fb_status,
        "Feedback_Comment": fb_comment
    }

    df.loc[len(df)] = nova_fila
