# cbr/similarity.py

"""
Càlcul de similituds del CBR.

Aquest mòdul implementa les funcions de similitud utilitzades per
comparar casos, basades en la vectorització d’atributs del menú
i en la similitud cosinus.
També inclou una mesura de compatibilitat a nivell de plats.
"""

# Imports
import numpy as np


# Similitud Cosinus
def cos_similarity(a, b):
    """
    Calcula la similitud cosinus entre dos vectors numèrics.

    Retorna un valor entre 0 i 1 i és robust davant vectors nuls.
    """
    
    a = np.array(a, dtype=float)
    b = np.array(b, dtype=float)

    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0.0

    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

# Vectorització dels atributs del menú
def vectoritzar(c, t, e):
    """
    Converteix (complexitat, temporada, estil) en un vector numèric robust,
    acceptant qualsevol cadena amb espais, majúscules, etc.
    """

    # Neteja d’entrada
    def clean(x):
        return str(x).strip().lower() if x is not None else None

    c = clean(c)
    e = clean(e)

    # Temporada pot ser llista → ho normalitzem
    if isinstance(t, list):
        t = [clean(x) for x in t]
    else:
        t = clean(t)

    comp_map = {
        "baixa":   [1,0,0],
        "mitjana": [0,1,0],
        "alta":    [0,0,1],
    }

    temp_map = {
        "hivern":     [1,0,0,0,0],
        "tardor":     [0,1,0,0,0],
        "primavera":  [0,0,1,0,0],
        "estiu":      [0,0,0,1,0],
        "anual":      [0,0,0,0,1],
    }

    estil_map = {
        "classic":   [1,0,0],
        "modern":    [0,1,0],
        "sibarita":  [0,0,1],
    }

    # Estil
    if e not in estil_map:
        # valor desconegut → vector zero
        v_estil = np.zeros(3)
    else:
        v_estil = np.array(estil_map[e])

    # Temporada
    if isinstance(t, list):
        valid = [temp_map[x] for x in t if x in temp_map]
        if valid:
            v_temp = np.mean(valid, axis=0)
        else:
            v_temp = np.zeros(5)
    else:
        if t in temp_map:
            v_temp = np.array(temp_map[t])
        else:
            v_temp = np.zeros(5)

    # Complexitat
    if c in comp_map:
        v_comp = np.array(comp_map[c])
    else:
        v_comp = np.zeros(3)

    # Vector final
    return np.concatenate([
        0.30 * v_comp,
        0.20 * v_temp,
        0.50 * v_estil
    ])

# Similitud de plats a nivell de case base
def similitud_plats_case(cas, preferencies):
    """
    Calcula la similitud entre la temporada del plat CASE i la temporada
    de l’usuari. És robust si falten dades.
    """

    temporada_user = str(preferencies["temporada"]).strip().lower()

    # Llista de plats del cas (entrants pot ser None)
    plats = []

    if cas.plats["entrants"]:
        plats.extend(cas.plats["entrants"])

    for key in ["principal", "segon", "postre"]:
        if cas.plats.get(key):
            plats.append(cas.plats[key])

    if not plats:
        return 0.0

    scores = []

    for plat in plats:
        temporada_plat = str(plat.get("Temporada", "")).strip().lower()

        if temporada_plat == temporada_user:
            scores.append(1.0)

        elif temporada_user in ["primavera", "tardor"] and temporada_plat in ["primavera", "tardor"]:
            scores.append(0.5)

        elif temporada_user in ["estiu", "hivern"] and temporada_plat in ["estiu", "hivern"]:
            scores.append(0.5)

        else:
            scores.append(0.0)

    if not scores:
        return 0.0

    return sum(scores) / len(scores)