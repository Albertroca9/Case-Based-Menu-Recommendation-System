# cbr/reuse.py

"""
Mòdul REUSE del sistema CBR.
Aplica adaptacions automàtiques sobre el cas recuperat:
    - Substitució de plats prohibits
    - Ajustos segons preferències
"""

# Imports
from copy import deepcopy
from data.carrega_dades import dicc_plat_ingredients

# Detecció d'ingredients prohibits
def plat_case_te_prohibit(plat_obj, prohibits):
    """
    Detecta si un plat CASE conté algun ingredient prohibit utilitzant
    el diccionari processat dicc_plat_ingredients.
    """

    if plat_obj is None or not prohibits:
        return False

    nom_plat = plat_obj.get("Nom-plat")
    if not nom_plat:
        return False

    # Ingredients normalitzats del plat (JSON processat)
    ing_plat = dicc_plat_ingredients.get(nom_plat, set())

    prohibits_norm = {p.lower() for p in prohibits}

    # Coincidència directa 
    return any(ing.lower() in prohibits_norm for ing in ing_plat)

# Substitució automàtica de plats prohibits
def substituir_plats_per_prohibits_CASE(cas_adaptat, preferencies, similars):
    """
    Aplica automàticament substitucions de plats prohibits sobre
    un Case complet.
    """

    prohibits = set(preferencies.get("ingredients_prohibits", []))
    if not prohibits:
        return cas_adaptat, []

    canvis = []
    plats = cas_adaptat.plats

    # Alternatives: tots els casos menys el principal
    casos_alternatius = [c for (c, _) in similars if c.menu_id != cas_adaptat.menu_id]

    # Entrants (llista)
    if plats["entrants"]:
        for idx, entr in enumerate(plats["entrants"]):

            if plat_case_te_prohibit(entr, prohibits):

                for cas_alt in casos_alternatius:
                    for e_alt in cas_alt.plats["entrants"] or []:
                        if not plat_case_te_prohibit(e_alt, prohibits):
                            canvis.append((entr["Nom-plat"], e_alt["Nom-plat"]))
                            plats["entrants"][idx] = deepcopy(e_alt)
                            break
                    else:
                        continue
                    break

    # Principal / Segon / Postre (1 plat cadascun)
    for tipus in ["principal", "segon", "postre"]:
        p = plats.get(tipus)

        if p and plat_case_te_prohibit(p, prohibits):
            for cas_alt in casos_alternatius:
                candidat = cas_alt.plats.get(tipus)

                if candidat and not plat_case_te_prohibit(candidat, prohibits):
                    canvis.append((p["Nom-plat"], candidat["Nom-plat"]))
                    plats[tipus] = deepcopy(candidat)
                    break

    return cas_adaptat, canvis

# Substitució manual (opcions d’usuari)
def substituir_plat_CASE(cas, preferencies, similars):
    """
    Permet substituir manualment un plat d’un cas per vegades d’un altre cas similar.

    Mostra els plats del menú actual, deixa a l’usuari seleccionar quin
    vol canviar i ofereix alternatives extretes dels casos més similars.
    Si l’usuari confirma el canvi, el plat es substitueix dins del cas.    
    """

    print("\n=================== SUBSTITUCIÓ MANUAL DE PLAT ===================")

    plats_llista = []

    # Entrants
    if cas.plats["entrants"]:
        for e in cas.plats["entrants"]:
            plats_llista.append(("Entrant", e))

    # Principal / Segon / Postre
    for key, label in [
        ("principal", "Principal"),
        ("segon",     "Segon"),
        ("postre",    "Postre")
    ]:
        p = cas.plats[key]
        if p:
            plats_llista.append((label, p))

    if not plats_llista:
        print("Aquest cas no té plats. No es pot substituir res.")
        return cas, False

    # Mostrar plats
    print("\nPLATS DISPONIBLES:")
    for i, (t, p) in enumerate(plats_llista, 1):
        print(f"  {i}. {t}: {p['Nom-plat']}")

    # Selecció usuari
    while True:
        op = input("\nQuin plat vols substituir? (Número, 0 per sortir)\n  >> ").strip()
        if op == "0":
            return cas, False
        if op.isdigit() and 1 <= int(op) <= len(plats_llista):
            idx = int(op) - 1
            tipus_sel, plat_sel = plats_llista[idx]
            break
        print("Opció no vàlida.")

    print(f"\n→ Has seleccionat substituir: {plat_sel['Nom-plat']} ({tipus_sel})")

    tipus_clau = tipus_sel.lower()
    if tipus_clau == "entrant":
        tipus_clau = "entrants"

    # Construir alternatives
    alternatives = []

    for cas_alt, _sim in similars[1:6]:  
        if tipus_clau == "entrants":
            for e_alt in cas_alt.plats["entrants"] or []:
                alternatives.append(e_alt)
        else:
            p_alt = cas_alt.plats[tipus_clau]
            if p_alt:
                alternatives.append(p_alt)

    # Unique
    uniques = []
    vistos = set()
    for p in alternatives:
        if p["Nom-plat"] not in vistos:
            uniques.append(p)
            vistos.add(p["Nom-plat"])

    alternatives = uniques

    if not alternatives:
        print("No hi ha alternatives disponibles.")
        return cas, False

    # Mostrar alternatives
    print("\nALTERNATIVES DISPONIBLES:")
    for i, p in enumerate(alternatives, 1):
        print(f"  {i}. {p['Nom-plat']}")

    # Selecció alternativa
    while True:
        op2 = input("\nQuina alternativa vols aplicar? (Número, 0 per cancel·lar)\n  >> ").strip()
        if op2 == "0":
            return cas, False
        if op2.isdigit() and 1 <= int(op2) <= len(alternatives):
            nou_plat = alternatives[int(op2)-1]
            break
        print("Opció no vàlida.")

    print(f"\n✓ Substituint «{plat_sel['Nom-plat']}» per «{nou_plat['Nom-plat']}»...\n")

    # Aplicar substitució
    if tipus_clau == "entrants":
        pos = cas.plats["entrants"].index(plat_sel)
        cas.plats["entrants"][pos] = nou_plat
    else:
        cas.plats[tipus_clau] = nou_plat

    return cas, True

# Funció principal de Reuse
def adaptar_cas(cas_recuperat, similars, preferencies):
    """
    Executa l’etapa REUSE:
        - fa còpia del cas
        - substitueix plats prohibits
        - retorna cas adaptat + llista de canvis
    """
    nou_cas = deepcopy(cas_recuperat)

    nou_cas, canvis = substituir_plats_per_prohibits_CASE(
        nou_cas,
        preferencies,
        similars
    )

    return nou_cas, canvis