# cbr/forget.py

"""
Mecanisme d’oblit del CBR.

Aquest mòdul controla el manteniment de la base de casos eliminant
menús adaptats poc rellevants quan el rendiment del sistema empitjora.
L’oblit es basa en el temps d’execució, la similitud amb les preferències
actuals i el feedback associat als casos.
"""

# Imports
import os
import pandas as pd
from datetime import datetime

from cbr.retrieve import retrieve_best

# RUTES
TIME_LOG   = "data/time_log.txt"
USAGE_LOG  = "data/us_menus.csv"
CASES_LOG  = "data/menus_adaptats.csv" ##########################################
PLATS_CSV  = "data/plats.csv"

TH_TIME = 50.0 # llindar en segons

def es_eliminable_row(row):
    """
    Decideix si un cas es pot eliminar segons el feedback.
    Els casos FAIL_ALLERGY són crítics i NO es poden eliminar.
    """
    status = row.get("Feedback_Status", None)

    if status == "FAIL_ALLERGY":
        return False

    return True


def forget_cases_based_on_time(preferencies=None):
    """
    - Calcula temps mitjà d'execució
    - Si supera TH_TIME → activa FORGET
    - Necessita preferències per recalcular similituds
    """

    # Si no hi ha registre de temps, no fem res
    if not os.path.exists(TIME_LOG):
        return

    with open(TIME_LOG, "r") as f:
        temps = [float(x.strip()) for x in f.readlines() if x.strip()]

    if not temps:
        return

    temps_mitja = (sum(temps) / len(temps)) / 100.0

    print(f"[FORGET] Temps mitjà actual: {temps_mitja:.3f} segons")

    if temps_mitja < TH_TIME:
        print("[FORGET] Tot correcte, no cal eliminar casos.")
        return

    print("[FORGET] ALERTA: rendiment baix! Activant FORGET…")

    if preferencies is None:
        print("[FORGET] ERROR: preferències no proporcionades.")
        return

    forget_keep_top3(preferencies)


def forget_keep_top3(preferencies):
    """
    Manté NOMÉS els 3 menús més similars (adults + infantil).
    """

    # Recalcular top 3
    top3_adults, _   = retrieve_best(preferencies, infantil=False)
    top3_infantil, _ = retrieve_best(preferencies, infantil=True)

    keep_ids = set()

    for cas, _ in top3_adults:
        keep_ids.add(cas.menu_id)

    for cas, _ in top3_infantil:
        keep_ids.add(cas.menu_id)

    # Afegir casos crítics (FAIL_ALLERGY)
    if os.path.exists(CASES_LOG):
        df_cases_all = pd.read_csv(CASES_LOG)

        if "Feedback_Status" in df_cases_all.columns:
            df_critical = df_cases_all[
                df_cases_all["Feedback_Status"] == "FAIL_ALLERGY"
            ]

            critical_ids = set(df_critical["Menu"].unique())
            keep_ids |= critical_ids

            print(f"[FORGET] Casos crítics protegits: {critical_ids}")

    print(f"[FORGET] Menús que es conservaran: {keep_ids}")

    # Eliminar de la base de dades
    plats_a_eliminar = []

    if os.path.exists(CASES_LOG):

        df_cases = pd.read_csv(CASES_LOG)

        # Files que NO són del TOP3
        df_remove = df_cases[
            (~df_cases["Menu"].isin(keep_ids)) &
            (df_cases.apply(es_eliminable_row, axis=1))
]
        # Guardem els noms dels plats adaptats que s'han de borrar de plats.csv
        plats_a_eliminar = df_remove["Nom-plat"].unique().tolist()

        # Escrivim només els casos que volem mantenir
        df_keep = df_cases.drop(df_remove.index)
        df_keep.to_csv(CASES_LOG, index=False)

        print(f"[FORGET] S’han eliminat {len(df_cases) - len(df_keep)} menús adaptats.")
        print(f"[FORGET] Plats adaptats a eliminar: {plats_a_eliminar}")

    # Eliminar registres d'us (us_menus.csv)
    if os.path.exists(USAGE_LOG):

        df_us = pd.read_csv(USAGE_LOG)

        df_us_keep = df_us[df_us["Menu_ID"].isin(keep_ids)]
        df_us_keep.to_csv(USAGE_LOG, index=False)

        print(f"[FORGET] Registres d’ús actualitzats. Es mantenen: {keep_ids}")

    # =======================================================================
    # 4) ELIMINAR PLATS ADAPTATS DE plats.csv ################################################
    # =======================================================================
    if plats_a_eliminar and os.path.exists(PLATS_CSV):

        df_plats = pd.read_csv(PLATS_CSV)

        df_plats_new = df_plats[~df_plats["Nom-plat"].isin(plats_a_eliminar)]
        df_plats_new.to_csv(PLATS_CSV, index=False)

        print(f"[FORGET] Eliminats {len(df_plats) - len(df_plats_new)} plats adaptats de plats.csv.")

    print("[FORGET] ✔ Procés completat amb èxit!\n")