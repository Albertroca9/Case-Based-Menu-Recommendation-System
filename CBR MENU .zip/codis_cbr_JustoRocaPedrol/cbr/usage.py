# cbr/usage.py

"""
Gestió del registre d’ús dels menús del CBR.

Aquest mòdul manté un historial bàsic d’ús dels menús recomanats,
emmagatzemant el nombre de vegades que s’han seleccionat i la
data de l’últim ús, per facilitar futures decisions de manteniment
i oblit de casos.
"""

# Imports
import os
import pandas as pd
from datetime import datetime

USAGE_PATH = "data/us_menus.csv"

COLUMNS = ["Menu_ID", "Comptador", "Ultim-ús"]


def ensure_usage_csv():
    """
    Crea el CSV si no existeix o si està buit.
    """
    
    if not os.path.exists("data"):
        os.makedirs("data")

    # Si no existeix → crear-lo
    if not os.path.exists(USAGE_PATH):
        df = pd.DataFrame(columns=COLUMNS)
        df.to_csv(USAGE_PATH, index=False)
        return

    # Si existeix però està buit → recrear-lo
    if os.path.getsize(USAGE_PATH) == 0:
        df = pd.DataFrame(columns=COLUMNS)
        df.to_csv(USAGE_PATH, index=False)
        return


def registrar_us(menu_id):
    """
    Registra l'ús d'un menú:
      - Incrementa comptador
      - Actualitza 'Ultim-ús'
      - Si no existeix → crea una nova fila
    """

    ensure_usage_csv() # assegurem la integritat del fitxer

    # Si el CSV està malformat o buit, recrear
    try:
        df = pd.read_csv(USAGE_PATH)
    except pd.errors.EmptyDataError:
        df = pd.DataFrame(columns=COLUMNS)

    ara = datetime.now().isoformat()

    # Si el menú ja existeix → incrementar ús
    if menu_id in df["Menu_ID"].values:
        df.loc[df["Menu_ID"] == menu_id, "Comptador"] += 1
        df.loc[df["Menu_ID"] == menu_id, "Ultim-ús"] = ara

    else:
        # Crear fila nova
        df.loc[len(df)] = {
            "Menu_ID": menu_id,
            "Comptador": 1,
            "Ultim-ús": ara
        }

    df.to_csv(USAGE_PATH, index=False)
