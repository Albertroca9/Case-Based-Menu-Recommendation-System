# cbr/retrieve.py

"""
Retrieve del sistema CBR:
- Rep les preferències de l’usuari (consulta)
- Compara la consulta amb tots els casos de la Case Base
- Retorna el millor cas + TOP-N similars
"""

# Imports
import numpy as np
from cbr.similarity import vectoritzar, cos_similarity, similitud_plats_case
from casos.case_base import CASE_BASE

# Càlcul de similitud d’un cas amb les preferències
def calcular_similitud(cas, preferencies):
    """
    Calcula la similitud entre:
      - preferències usuari
      - cas (Case object)
    """

    comp_user = preferencies["complexitat_adults"] # adults per defecte
    temporada_user = preferencies["temporada"]
    estil_user = preferencies["estil_menu"]

    v_user = vectoritzar(comp_user, temporada_user, estil_user)
    v_case = vectoritzar(cas.complexitat, cas.temporada, cas.estil)

    sim_ont = cos_similarity(v_user, v_case)
    sim_plats = similitud_plats_case(cas, preferencies)

    return 0.6 * sim_ont + 0.4 * sim_plats

def ajustar_similitud_per_feedback(cas, sim):
    """
    Ajusta la similitud segons feedback del cas.
    - FAIL_ALLERGY: penalització forta
    - FAIL_TASTE: penalització suau
    - SUCCESS: sense penalització
    """
    fb = getattr(cas, "feedback", None)
    if not fb:
        return sim

    status = fb.get("status")

    if status == "FAIL_ALLERGY":
        return sim * 0.1  
    if status == "FAIL_TASTE":
        return sim * 0.7

    return sim

# Retrieve dels millors casos
def retrieve_best(preferencies, infantil=False):
    """
    Retrieve dels top 3 casos més similars (adults o infantil).
    """

    similituds = []

    # Filtrar i calcular similitud
    for menu_id, cas in CASE_BASE.items():

        # Adults → excloure infantil
        if not infantil and menu_id.startswith("MenuInf"):
            continue

        # Infantil → excloure adults
        if infantil and not menu_id.startswith("MenuInf"):
            continue

        sim_base = calcular_similitud(cas, preferencies)
        sim = ajustar_similitud_per_feedback(cas, sim_base)
        similituds.append((cas, sim))
        
    # Ordena per similitud descendent
    similituds.sort(key=lambda x: x[1], reverse=True)

    if not similituds:
        raise ValueError(f"No s'han trobat menús per infantil={infantil}")

    # Triar els top 3 casos
    top3 = similituds[:3]

    # Retornar top 3 + tota la llista ordenada
    return top3, similituds