# casos/representacio.py
"""
Representació formal dels casos del CBR.
Cada cas correspon a un menú complet i conté:
  → informació del problema
        - complexitat
        - temporada
        - estil
  → informació de la solució
        - tots els plats del menú amb tots els seus atributs

Aquest fitxer només defineix l'estructura d'un cas i
funcions auxiliars per construir-lo.
"""

class Case:
    def __init__(self, menu_id, complexitat, temporada, estil, plats):
        """
        menu_id : str
        complexitat : str  (baixa/mitjana/alta)
        temporada : str o llista  (primavera, estiu, ...)
        estil : str  (classic/modern/sibarita)
        plats : dict amb estructura:

            {
                "entrants": [plat_dict, plat_dict, ...],
                "principal": plat_dict,
                "segon": plat_dict,
                "postre": plat_dict
            }
        """
        self.menu_id = menu_id
        self.complexitat = complexitat
        self.temporada = temporada
        self.estil = estil
        self.plats = plats  # tots els plats amb tots els atributs
        # Determina si el menú és infantil
        tots_plats = []
        for key in ["entrants", "principal", "segon", "postre"]:
            val = plats[key]
            if isinstance(val, list):
                tots_plats.extend(val)
            elif isinstance(val, dict) and val:
                tots_plats.append(val)

        self.es_infantil = all(p.get("Tipus-public", "").lower() == "nens"
                            for p in tots_plats if p)
        self.feedback = {
            "rating": None, # 1..10
            "status": None, # SUCCESS | FAIL_ALLERGY | FAIL_TASTE
            "comment": None # text lliure
        }


    def __repr__(self):
        return f"<Case {self.menu_id} ({self.complexitat}, {self.temporada}, {self.estil})>"


def crear_plat_dict(fila):
    """
    Converteix una fila d'un DataFrame de plats en un diccionari complet.
    Això garanteix que cada plat té TOTS els seus atributs disponibles
    per a adaptació, justificació i comparació.
    """
    return {
        "Nom-plat": fila["Nom-plat"],
        "Complexitat": fila["Complexitat"],
        "Ingredients-4p": fila["Ingredients-4p"],
        "Sabor": fila["Sabor"],
        "Tecniques": fila["Tecniques"],
        "Origen-plat": fila["Origen-plat"],
        "Preu-plat": fila["Preu-plat"],
        "Temperatura": fila["Temperatura"],
        "Temporada": fila["Temporada"],
        "Tipus-plat": fila["Tipus-plat"],
        "Tipus-public": fila["Tipus-public"],
        "Estil-plat": fila["Estil-plat"],
        "Menu": fila["Menu"]
    }


def crear_case(menu_id, df_plats):
    """
    Construeix un cas COMPLET a partir del DataFrame df_plats.

    1) Filtra els plats del menú
    2) Construeix els diccionaris de cada plat
    3) Agafa metadades globals del menú (complexitat, estil, temporada)
    4) Retorna un objecte Case

    Retorna:
        Case(...)
    """

    # Filtrar les files del menú concret
    df_menu = df_plats[df_plats["Menu"] == menu_id]

    if len(df_menu) == 0:
        raise ValueError(f"El menú {menu_id} no existeix a la base de plats.")

    # Entrants (pot haver-n'hi 0, 1 o més)
    entrants_rows = df_menu[df_menu["Tipus-plat"] == "Entrant"]
    entrants = [crear_plat_dict(row) for _, row in entrants_rows.iterrows()]

    # Principal
    principal_row = df_menu[df_menu["Tipus-plat"] == "Principal"]
    principal = crear_plat_dict(principal_row.iloc[0]) if len(principal_row) else None

    # Segon
    segon_row = df_menu[df_menu["Tipus-plat"] == "Segon"]
    segon = crear_plat_dict(segon_row.iloc[0]) if len(segon_row) else None

    # Postre
    postre_row = df_menu[df_menu["Tipus-plat"] == "Postre"]
    postre = crear_plat_dict(postre_row.iloc[0]) if len(postre_row) else None

    # Informació del menú
    first_row = df_menu.iloc[0]

    return Case(
        menu_id=menu_id,
        complexitat=first_row["Complexitat"],
        temporada=first_row["Temporada"],
        estil=first_row["Estil-plat"],
        plats={
            "entrants": entrants,
            "principal": principal,
            "segon": segon,
            "postre": postre
        }
    )