# casos/menu_ontology.py

"""
Definició de l’ontologia bàsica dels menús del sistema CBR.

Aquest fitxer conté el diccionari `menu_characteristics`, que associa
cada identificador de menú (MenuX, MenuInfX) amb els seus atributs
ontològics principals:
    - Complexitat del menú (baixa / mitjana / alta)
    - Temporades en què és adequat (llista que pot contenir els valors: 
        primavera, estiu, tardor, hivern, anual)
    - Estil gastronòmic (classic / modern / sibarita)
"""

# Diccionari amb les característiques ontològiques de cada menú
menu_characteristics = {
    # BAIXA
    "Menu1":  ("baixa", ["primavera"], "modern"),
    "Menu2":  ("baixa", ["hivern"], "modern"),
    "Menu3":  ("baixa", ["primavera"], "modern"),
    "Menu4":  ("baixa", ["tardor"], "modern"),
    "Menu5":  ("baixa", ["estiu"], "modern"),
    "Menu6":  ("baixa", ["primavera"], "modern"),

    "Menu7":  ("baixa", ["anual"], "classic"),
    "Menu8":  ("baixa", ["hivern", "tardor"], "classic"),
    "Menu9":  ("baixa", ["estiu"], "classic"),
    "Menu10": ("baixa", ["primavera", "tardor"], "classic"),

    "Menu11": ("baixa", ["estiu"], "sibarita"),
    "Menu12": ("baixa", ["tardor"], "sibarita"),
    "Menu13": ("baixa", ["anual"], "sibarita"),
    "Menu14": ("baixa", ["primavera"], "sibarita"),

    # MITJANA
    "Menu15": ("mitjana", ["estiu", "tardor"], "classic"),
    "Menu16": ("mitjana", ["anual", "hivern"], "classic"),
    "Menu17": ("mitjana", ["tardor"], "modern"),
    "Menu18": ("mitjana", ["estiu"], "modern"),
    "Menu19": ("mitjana", ["primavera"], "modern"),
    "Menu20": ("mitjana", ["anual", "hivern"], "modern"),
    "Menu21": ("mitjana", ["hivern", "anual", "tardor"], "sibarita"),
    "Menu22": ("mitjana", ["primavera", "estiu"], "sibarita"),

    # ALTA
    "Menu23": ("alta", ["primavera", "anual", "hivern", "estiu", "tardor"], "classic"),
    "Menu24": ("alta", ["primavera", "anual", "estiu"], "modern"),
    "Menu25": ("alta", ["hivern", "tardor"], "modern"),
    "Menu26": ("alta", ["anual", "estiu"], "sibarita"),
    "Menu27": ("alta", ["tardor", "primavera"], "sibarita"),
    "Menu28": ("alta", ["hivern"], "sibarita"),

    # INFANTILS BAIXA
    "MenuInf1":  ("baixa", ["estiu"], "classic"),
    "MenuInf2":  ("baixa", ["primavera"], "classic"),
    "MenuInf3":  ("baixa", ["tardor"], "classic"),
    "MenuInf4":  ("baixa", ["hivern"], "classic"),
    "MenuInf5":  ("baixa", ["anual"], "classic"),
    "MenuInf6":  ("baixa", ["estiu"], "modern"),
    "MenuInf7":  ("baixa", ["primavera"], "modern"),
    "MenuInf8":  ("baixa", ["tardor"], "modern"),
    "MenuInf9":  ("baixa", ["hivern"], "modern"),
    "MenuInf10": ("baixa", ["anual"], "modern"),

    # INFANTILS MITJANA
    "MenuInf11": ("mitjana", ["estiu"], "classic"),
    "MenuInf12": ("mitjana", ["primavera"], "classic"),
    "MenuInf13": ("mitjana", ["tardor"], "classic"),
    "MenuInf14": ("mitjana", ["hivern"], "classic"),
    "MenuInf15": ("mitjana", ["anual"], "classic"),
    "MenuInf16": ("mitjana", ["estiu"], "modern"),
    "MenuInf17": ("mitjana", ["primavera"], "modern"),
    "MenuInf18": ("mitjana", ["tardor"], "modern"),
    "MenuInf19": ("mitjana", ["hivern"], "modern"),
    "MenuInf20": ("mitjana", ["anual"], "modern"),
}