# casos/case_base.py

"""
Construcció i gestió de la base de casos (Case Base) del sistema CBR.

Cada cas és un menú complet (entrants, principal, segon, postre)
representat amb tots els seus atributs (via casos.representacio.Case).
"""

# Imports
from casos.representacio import crear_case
from data.carrega_dades import plats

# Construcció de la case-base
def construir_case_base():
    """
    Llegeix tots els menús existents i construeix un objecte Case per cadascun.
    Retorna un diccionari {menu_id : Case}
    """
    case_base = {}

    # Tots els menús únics
    llista_menus = [
        m for m in plats["Menu"].unique().tolist()
        if isinstance(m, str) and m.strip() != "" and m == m
    ]

    # Construir un case per cada menú
    for menu_id in llista_menus:
        try:
            case = crear_case(menu_id, plats)
            case_base[menu_id] = case
        except Exception as e:
            print(f"[WARNING] No s'ha pogut crear el cas per {menu_id}: {e}")

    return case_base


# CASE BASE
# Es genera una única vegada en carregar el mòdul
CASE_BASE = construir_case_base()


# FUNCIONS PÚBLIQUES
def get_case(menu_id):
    """
    Retorna un cas concret (Case) o None si no existeix.
    """
    return CASE_BASE.get(menu_id)

def get_all_cases():
    """
    Retorna tots els casos existents com una llista.
    """
    return list(CASE_BASE.values())

def print_case_base_summary():
    """
    Mostra per debug quants casos tens i quins menús cobreixen.
    """
    print("\n===== CASE BASE SUMMARY =====")
    print(f"Total casos: {len(CASE_BASE)}\n")
    for cid in CASE_BASE:
        print(f" - {cid}")
    print("=============================\n")
